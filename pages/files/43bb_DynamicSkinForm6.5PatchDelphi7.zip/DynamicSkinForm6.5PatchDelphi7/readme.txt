Patch for DynamicSkinForm 6.5 trial delphi 7

download:  http://www.almdev.com


Copy this Patch in a folder with DynamicSkinForm.dcu and press Apply Patch .

