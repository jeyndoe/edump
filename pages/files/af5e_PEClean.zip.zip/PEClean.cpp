/*

  PE Cleaner
  An utility to clean the space between
  header and the first section of PE file

  Written by Tim
  E-mail: timqwerty@yandex.ru

  12/27/2005  0.01  ������ ������

*/

#include <windows.h>
#include <stdio.h>

void Error(char *format, ...)
{
  va_list paramList;
  va_start(paramList, format);
  vprintf(format, paramList);
  va_end(paramList);
  exit(1);
}

DWORD AbsoluteSeek(HANDLE hFile,
                   DWORD  offset)
{
  DWORD newOffset;

  if((newOffset = SetFilePointer(hFile,
                                 offset,
                                 NULL,
                                 FILE_BEGIN)) == 0xFFFFFFFF)
    Error("SetFilePointer failed, error %lu.\n", GetLastError());

  return newOffset;
}

void ReadBytes(HANDLE hFile,
               LPVOID buffer,
               DWORD  size)
{
  DWORD bytes;

  if(!ReadFile(hFile,
               buffer,
               size,
               &bytes,
               NULL))
    Error("ReadFile failed, error %lu.\n", GetLastError());
  else if(size != bytes)
    Error("Read the wrong number of bytes, expected %lu, got %lu.\n", size, bytes);
}

int main(int argc, char* argv[])
{

  HANDLE hImage;

  DWORD  bytes;
  DWORD  iSection;
  DWORD  SectionOffset;
  DWORD  CoffHeaderOffset;
  DWORD  MoreDosHeader[16];

  ULONG  ntSignature;

  IMAGE_DOS_HEADER      image_dos_header;
  IMAGE_FILE_HEADER     image_file_header;
  IMAGE_OPTIONAL_HEADER image_optional_header;
  IMAGE_SECTION_HEADER  image_section_header;

  int   filename_size = GetFileTitle(argv[0], NULL, 0);
  char *filename      = new char[filename_size];
  ZeroMemory(filename, filename_size);
  GetFileTitle(argv[0], filename, filename_size);

  printf("PE Cleaner v0.01 (timqwerty@yandex.ru)\n");

  if(argc != 2)
    Error("Usage: %s program_file_name\n", filename);

  printf("\n");

  /*
   *  Open the reference file.
   */
  printf("Open reference file         ");

  hImage = CreateFile(argv[1],
                      GENERIC_READ | GENERIC_WRITE,
                      FILE_SHARE_READ,
                      NULL,
                      OPEN_EXISTING,
                      FILE_ATTRIBUTE_NORMAL,
                      NULL);

  if(hImage == INVALID_HANDLE_VALUE)
    Error("Couldn't open %s, error %lu.\n", argv[1], GetLastError());

  printf("ok.\n");

  /*
   *  Read the MS-DOS image header.
   */
  printf("Read MS-DOS image header    ");

  ReadBytes(hImage,
            &image_dos_header,
            sizeof(IMAGE_DOS_HEADER));

  if(image_dos_header.e_magic != IMAGE_DOS_SIGNATURE)
    Error("Unknown file format.\n");

  printf("ok.\n");

  /*
   *  Read more MS-DOS header.
   */
  printf("Read more MS-DOS header     ");

  ReadBytes(hImage,
            MoreDosHeader,
            sizeof(MoreDosHeader));

  printf("ok.\n");

  /*
   *  Get actual COFF header.
   */
  printf("Read actual COFF header     ");

  CoffHeaderOffset = AbsoluteSeek(hImage, image_dos_header.e_lfanew)
                   + sizeof(ULONG);

  ReadBytes(hImage, &ntSignature, sizeof(ULONG));

  if(ntSignature != IMAGE_NT_SIGNATURE)
    Error("Missing NT signature. Unknown file type.\n");

  SectionOffset = CoffHeaderOffset
                + IMAGE_SIZEOF_FILE_HEADER
                + IMAGE_SIZEOF_NT_OPTIONAL_HEADER;

  ReadBytes(hImage,
            &image_file_header,
            IMAGE_SIZEOF_FILE_HEADER);

  printf("ok.\n");

  /*
   *  Read optional header.
   */
  printf("Read optional header        ");

  ReadBytes(hImage,
            &image_optional_header,
            IMAGE_SIZEOF_NT_OPTIONAL_HEADER);

  printf("ok.\n");

  // -----

  /*
   *  Read the first section.
   */
  printf("Read first section          ");

  AbsoluteSeek(hImage, SectionOffset);

  ReadBytes(hImage,
            &image_section_header,
            sizeof(IMAGE_SECTION_HEADER));

  printf("ok.\n");

  /*
   *  Clean it! =)
   */
  DWORD from_offset = SectionOffset
                    + image_file_header.NumberOfSections
                    * sizeof(IMAGE_SECTION_HEADER);
  DWORD to_offset   = image_section_header.PointerToRawData;
  DWORD n;

  BYTE buf[] = { 0x00 };

  printf("  Cave start    %Xh\n",         from_offset);
  printf("  Cave end      %Xh\n",         to_offset);
  printf("  Cave size     %lu byte(s)\n", to_offset - from_offset);

  printf("Cleaning                    ");

  for(DWORD i = from_offset; i < to_offset; i++)
  {
    AbsoluteSeek(hImage, i);

    if(!WriteFile(hImage,
                  buf,
                  1,
                  &n,
                  NULL))
      Error("failed, error %lu.\n", GetLastError());
  }

  printf("ok.\n");

  // -----

  CloseHandle(hImage);

  return 0;

}
