Generate a 640 Product Key for WinXP Pro Corporate Editions      
with Service Pack 2.���������������������������������������      
The Windows update v5 via web works fine!                        

Run Program                                                   
- change product family to "Windows XP Pro VLK"                  
- Hit "Generate" as many times you like,                         
and pick your unique license key                               
                                                 
- select order by phone                                         
- hit next                                                       
- hit change product key                                         
- enter new key                                                  
- close window                                                   
- Restart your computer                                          
- you're done!                                                   