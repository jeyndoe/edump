StarForce file system antiblock driver by AlB (version 1.0.h).

1. Manual disable (disconnect cables from) all satisfacted CD/DVD drives on _I_D_E_ controllers. SFNightmare doesn't works very frequently.

2. Edit "sfcure01.reg" for start type. 2-Auto, 3-Manual. Default is 3-Manual.

3. Run "!setup.bat" for driver install.

4. For manual start type use:
	Run "!start.bat" for driver start.
	Run "!stop.bat"  for driver stop.

5. Use "StarforceNightmare 1.12" disable node function for disable virtual drive blacklisting.
Or use "Win2K3 Node Disabler" for it. For me it was only one working way under Win2K.

6. Start Starforce (prior 3.7) game with correct disc image in virtual drive (Alcohol120% v1.9.5 build 3105).

ps. 
1. Of couse, you must have admin rights.
2. Various WinNT x86 (with DEP too) supported and tested.
3. Uninstall all hardware access software tracers and logers.
4. Special tnx to DKTigra for nice tool and sti for suggestion.
5. Don't forget input virtual drive drivers to "Win2K3 Node Disabler" list.
