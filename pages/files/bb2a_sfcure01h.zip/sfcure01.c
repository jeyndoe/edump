//---------------------------------------------------------------------------

#include <ddk\ntddk.h>

//---------------------------------------------------------------------------

// interupt control: 0 - disabled, 1 - enabled
VOID int_control(int x)
{
if (x == 0)	asm("cli;");	// disable (CLear Int enable flag)
else		asm("sti;");	// enable (SeT Int enable flag)
}

// for store original reg cr0 value
ULONG OrgCR0;

// "write protect" attrib control: 0 - disable, 1 - restore original value 
VOID wp_control(int x)
{
ULONG SetCR0;
if (x == 0) {
	asm("mov %%cr0,%%eax; mov %%eax,%0;" : "=m" (OrgCR0) :);
	SetCR0 = OrgCR0 & 0xFFFEFFFF;
} else {
	SetCR0 = OrgCR0;
}
asm("mov %0,%%eax; mov %%eax,%%cr0;" :: "m" (SetCR0));
}

//---------------------------------------------------------------------------

extern VOID DrvProc_XP() asm ("DRIVER_PROC_XP"); // import asm function
extern VOID DrvProc_2K() asm ("DRIVER_PROC_2K"); // import asm function
// it's will be injected to IofCallDriver and will be called between IofCallDriver and target driver function

PUCHAR PatchXP = NULL; // pointer to founded IofCallDriver code for XP

UCHAR Buf1_XP[] = {
	0x52,	// push edx
	0x51,	// push ecx
	0xFF, 0x54, 0x86, 0x38	// call [esi+4*eax+38h]
}; // target replace code

UCHAR Buf2_XP[] = {
	0x90,	// nop
	0xE8, 0x00, 0x00, 0x00, 0x00	// call xxx
}; // replace code

PUCHAR Patch2K = NULL; // pointer to founded IofCallDriver code for XP

UCHAR Buf1_2K[] = {
	0x56,	// push esi
	0x83, 0xE8, 0x24,	// sub eax, 24
	0x57,	// push edi
	0x89, 0x46, 0x60,	// mov {esi+60], eax
	0x89, 0x78, 0x14,	// mov [eax+14], edi
	0x8B, 0x4F, 0x08,	// mov ecx, [edi+8]
	0x0F, 0xB6, 0x00,	// movzx eax, byte ptr [eax]
	0xFF, 0x54, 0x81, 0x38	// call [ecx+4*eax+38h]
}; 

UCHAR Buf2_2K[] = {
	0x90,	// nop
	0x83, 0xE8, 0x24,	// sub eax, 24
	0x89, 0x46, 0x60,	// mov {esi+60], eax
	0x89, 0x78, 0x14,	// mov [eax+14], edi
	0x8B, 0x4F, 0x08,	// mov ecx, [edi+8]
	0x0F, 0xB6, 0x00,	// movzx eax, byte ptr [eax]
	0xE8, 0x00, 0x00, 0x00, 0x00	// call xxx
};

// Attention. There is possible to crash system when driver load/unload 
// and any thread will be at this point. But chance is very very small.
// Do not patch code after "call" because:
// 1. new call code alligned at end with old call
// 2. it's significtly increase crash chance (unknown functon lenght).

//---------------------------------------------------------------------------
// unload driver and restore IofCallDriver

__stdcall VOID DriverUnload(PDRIVER_OBJECT DriverObject)
{
int i;

int_control(0);
wp_control(0);

if (PatchXP) {	// XP
	for(i=0; i < sizeof(Buf1_XP); i++) {
		PatchXP[i] = Buf1_XP[i];
	}
} 

if (Patch2K) {	// 2K
	for(i=0; i < sizeof(Buf1_2K); i++) {
		Patch2K[i] = Buf1_2K[i];
	}
}

wp_control(1);
int_control(1);

return;
}

//---------------------------------------------------------------------------
// load driver, search for code replace

__stdcall NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
int i, j;
PUCHAR Patch;

int_control(0);
wp_control(0);

Patch = (PUCHAR) IoCallDriver - 64; // smart compiler give us IofCallDriver
for(i = 0; i < 128; i++) { // searching code in 64 byte bound at IofCallDriver
	for(j=0; j < sizeof(Buf1_XP); j++) { // search
		if (Patch[j] != Buf1_XP[j]) break;
	}
	if (j == sizeof(Buf1_XP)) { // found
		PatchXP = Patch;
		// calculate correct call address to our asm function
		*((PULONG)(Buf2_XP+sizeof(Buf2_XP)-4)) = (ULONG)DrvProc_XP - ((ULONG)PatchXP + sizeof(Buf2_XP));
		for(i=0; i < sizeof(Buf2_XP); i++) { 
			PatchXP[i] = Buf2_XP[i]; // code replace
		}
		break;
	}
	Patch++;
}

Patch = (PUCHAR) IoCallDriver - 64;  // smart compiler give us IofCallDriver
for(i = 0; i < 128; i++) { // searching code in 64 byte bound at IofCallDriver
	for(j=0; j < sizeof(Buf1_2K); j++) { // search
		if (Patch[j] != Buf1_2K[j]) break;
	}
	if (j == sizeof(Buf1_2K)) { // found
		Patch2K = Patch;
		// calculate correct call address to our asm function
		*((PULONG)(Buf2_2K+sizeof(Buf2_2K)-4)) = (ULONG)DrvProc_2K - ((ULONG)Patch2K + sizeof(Buf2_2K));
		for(i=0; i < sizeof(Buf2_2K); i++) { 
			Patch2K[i] = Buf2_2K[i]; // code replace
		}
		break;
	}
	Patch++;
}
wp_control(1);
int_control(1);

if (!(PatchXP || Patch2K)) { // code not replaced
	return STATUS_NOT_IMPLEMENTED;
}

DriverObject->DriverUnload = DriverUnload;

return STATUS_SUCCESS;
}

//---------------------------------------------------------------------------
