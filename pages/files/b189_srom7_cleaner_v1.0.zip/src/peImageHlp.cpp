/*
	PeImageHlp (c) doug


	-> All functions use custom SetLastError messages.
	-> __try / __except		used conditionally, define PEIMAGE_DONT_USE_EXCEPTION_HANDLING to disable them.
*/



/*
TBDTBD:


Section Management (Add/Del/...)
================================
PeImageAddNewSection	// adds a new section at the end. Updates PE header.
PeImageRemoveSection	// removes a section given its index; give option to rebase everything after if there's a .reloc. Updates PE header.
PeImageInsertSection	// inserts an image at the given index, shifts everything after; give option to rebase everything after if there's a .reloc. Updates PE header.

  Random thoughts
  ----------------
  -> PeImageAddNewSection should probably call PeImageInsertSection
  
  -> rebase if there is a .reloc
  -> update pe header directory &  ntheader fields & obviously section entry
  -> new section size
  -> section index
  -> data appended at the end ("overlay") ? verify MapViewOfFile implementation


Directory Functions
===================
Do an implementation of imagehlp!ImageDirectoryEntryToDataEx (PeImageDirectoryEntryToDataEx)

*/

/*
	The ... function 



	Parameters
	----------
	: 


	Return Values
	-------------
	Success: 
	Error:
*/

// #define PEIMAGE_DONT_USE_EXCEPTION_HANDLING	TRUE
#include <windows.h>
#include <Dbghelp.h>
#include "peImageHlp.h"


/*
	The PeImageRvaToSection function locates a relative virtual address (RVA) within the image header of 
	a file that is mapped as a file and returns a pointer to the section table entry for that virtual address.


	Improves on ImageRvaToSection from ImageHlp.dll

	Parameters
	----------
	[in] NtHeaders: Pointer to an IMAGE_NT_HEADERS structure.
	[in] Base: Base address of an image that is mapped into memory through a call to MapViewOfFile
	[in] Rva: Relative virtual address to be located
	[in] MemDisplacements: set to TRUE if the computations should use values according to what the file looks like when loaded by Windows
							to FALSE if the computations [...] what it looks like on disk. (this is the imagehlp!ImageRvaToSection behavior)

	Return Values
	-------------
	Success: pointer to the section table entry for that RVA
	Error: NULL
 */
PIMAGE_SECTION_HEADER WINAPI PeImageRvaToSection(PIMAGE_NT_HEADERS NtHeaders, PVOID Base, ULONG Rva, BOOL MemDisplacements)
{
	PIMAGE_SECTION_HEADER pSection;
	DWORD i=0, sectionSize=0;

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	__try {
	#endif

	pSection = (PIMAGE_SECTION_HEADER) (((LPBYTE)&NtHeaders->OptionalHeader) + NtHeaders->FileHeader.SizeOfOptionalHeader);

	while (i < NtHeaders->FileHeader.NumberOfSections) {
	
		if ( pSection->VirtualAddress <= Rva) {
			if (MemDisplacements) {
				sectionSize = pSection->Misc.VirtualSize;
			}
			else {
				sectionSize = pSection->SizeOfRawData;
			}

			if (pSection->VirtualAddress + sectionSize > Rva) {
				return pSection;
			}
		}

		pSection++;
		i++;
	}

	SetLastError(ERROR_RVA_NOT_IN_IMAGE);
	return NULL;

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	} __except(EXCEPTION_EXECUTE_HANDLER) {
		SetLastError(ERROR_EXCEPTION_OCCURED);
		return NULL;
	}
	#endif // PEIMAGE_DONT_USE_EXCEPTION_HANDLING
}



/*
	The PeImageRawOffsetToSection function locates a raw offset within the image header of a file that is mapped
	as a file and returns a pointer to the section table entry for that raw offset.


	Parameters
	----------
	[in] NtHeaders: Pointer to an IMAGE_NT_HEADERS structure.
	[in] RawOffset: Raw Offset to be located.


	Return Values
	-------------
	Success: pointer to the section table entry for that Raw Offset
	Error: NULL
*/
PIMAGE_SECTION_HEADER WINAPI PeImageRawOffsetToSection(PIMAGE_NT_HEADERS NtHeaders, ULONG RawOffset)
{
	PIMAGE_SECTION_HEADER pSection;
	DWORD i=0, sectionSize=0;

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	__try {
	#endif
	pSection = (PIMAGE_SECTION_HEADER) (((LPBYTE)&NtHeaders->OptionalHeader) + NtHeaders->FileHeader.SizeOfOptionalHeader);

	// section search loop
	while(i < NtHeaders->FileHeader.NumberOfSections) {
		
		if ( pSection->PointerToRawData <= RawOffset) {
			if (pSection->PointerToRawData + pSection->SizeOfRawData > RawOffset) {
				return pSection;
			}
		}

		pSection++;
		i++;
	}

	SetLastError(ERROR_RAW_OFFSET_NOT_IN_IMAGE);
	return NULL;

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	} __except(EXCEPTION_EXECUTE_HANDLER) {
		SetLastError(ERROR_EXCEPTION_OCCURED);
		return NULL;
	}
	#endif // PEIMAGE_DONT_USE_EXCEPTION_HANDLING
}



/*
	The PeImageGetLastSection function locates the last section table entry from the given image header.


	Parameters
	----------
	[in] NtHeaders: Pointer to an IMAGE_NT_HEADERS structure. 


	Return Values
	-------------
	Success: Last section table entry
	Error: NULL
*/
PIMAGE_SECTION_HEADER WINAPI PeImageGetLastSection(PIMAGE_NT_HEADERS NtHeaders)
{
	PIMAGE_SECTION_HEADER pSection;

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	__try {
	#endif

	pSection = (PIMAGE_SECTION_HEADER) (((LPBYTE)&NtHeaders->OptionalHeader) + NtHeaders->FileHeader.SizeOfOptionalHeader);

	return (pSection + (NtHeaders->FileHeader.NumberOfSections - 1));


	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	} __except(EXCEPTION_EXECUTE_HANDLER) {
		SetLastError(ERROR_EXCEPTION_OCCURED);
		return NULL;
	}
	#endif // PEIMAGE_DONT_USE_EXCEPTION_HANDLING
}



/*
	The PeImageRVAtoRawOffset function locates an RVA within the image header of a file and returns the 
	corresponding raw offset, if it exists.



	Parameters
	----------
	[in] NtHeaders: Pointer to an IMAGE_NT_HEADERS structure.
	[in] Base: same
	[in] Rva: RVA to be located

	
	Return Values
	-------------
	Success: Raw Offset corresponding to the input Rva
	Error: -1
*/
DWORD WINAPI PeImageRVAtoRawOffset(PIMAGE_NT_HEADERS NtHeaders, PVOID Base, ULONG Rva)
{
	PIMAGE_SECTION_HEADER pSection;
	DWORD delta;

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	__try {
	#endif

	// find section
	if ((pSection=PeImageRvaToSection(NtHeaders, Base, Rva, TRUE))==NULL) {
		SetLastError(ERROR_RVA_NOT_IN_IMAGE);
		return -1;
	}
	
	// get RVA delta from the start of the section
	delta = Rva - pSection->VirtualAddress;

	// check if there exists a correspondance in the raw image
	if (delta >= pSection->SizeOfRawData) {
		SetLastError(ERROR_RVA_NOT_IN_RAW_IMAGE);
		return -1;
	}

	return (delta+pSection->PointerToRawData);

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	} __except(EXCEPTION_EXECUTE_HANDLER) {
		SetLastError(ERROR_EXCEPTION_OCCURED);
		return -1;
	}
	#endif // PEIMAGE_DONT_USE_EXCEPTION_HANDLING
}



/*
	The PeImageRawOffsetToRVA function locates a raw offset within the image header of a file and returns the 
	corresponding RVA.



	Parameters
	----------
	[in] NtHeaders: Pointer to an IMAGE_NT_HEADERS structure.
	[in] Base: same
	[in] RawOffset: RawOffset to be located

	Return Values
	-------------
	Success: RVA corresponding to the input RawOffset
	Error: -1
*/
DWORD WINAPI PeImageRawOffsetToRVA(PIMAGE_NT_HEADERS NtHeaders, PVOID Base, ULONG RawOffset, BOOL MemDisplacements)
{
	PIMAGE_SECTION_HEADER pSection;
	DWORD delta;

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	__try {
	#endif

	// find section
	if ((pSection=PeImageRawOffsetToSection(NtHeaders, RawOffset))==NULL) {
		SetLastError(ERROR_RVA_NOT_IN_IMAGE);
		return -1;
	}

	// get offset from the start of the section (on disk)
	delta = RawOffset - pSection->PointerToRawData;


	if (delta>=pSection->Misc.VirtualSize) {
		SetLastError(ERROR_RAW_OFFSET_NOT_MAPPED);
		return -1; // rawOffset not mapped to memory (is this possible?)
	}

	return (delta+pSection->VirtualAddress);
	
	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	} __except(EXCEPTION_EXECUTE_HANDLER) {
		SetLastError(ERROR_EXCEPTION_OCCURED);
		return -1;
	}
	#endif // PEIMAGE_DONT_USE_EXCEPTION_HANDLING

}


/*
	The ImageNtHeader function locates the IMAGE_NT_HEADERS structure in a PE image and returns a pointer to the data. 


	Parameters
	----------
	[in] ImageBase: Base address of an image that is mapped into memory by a call to the MapViewOfFile function.


	Return Values
	-------------
	Success: a pointer to an IMAGE_NT_HEADERS structure.
	Error: NULL
*/
PIMAGE_NT_HEADERS WINAPI PeImageNtHeader(PVOID ImageBase)
{
	PIMAGE_DOS_HEADER	dosHeader=NULL;
	PIMAGE_NT_HEADERS	ntHeader=NULL;
	
	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	__try {
	#endif

	if (ImageBase == NULL || ImageBase == (PVOID)0xFFFFFFFF) {
		SetLastError(ERROR_INVALID_PARAMETER);
		return NULL;
	}

	dosHeader = (PIMAGE_DOS_HEADER)ImageBase;
	if (dosHeader->e_magic != IMAGE_DOS_SIGNATURE || dosHeader->e_lfanew >= 0x10000000) {
		SetLastError(ERROR_INVALID_DOS_FILE);
		return NULL;
	}

	ntHeader=(PIMAGE_NT_HEADERS)((LPBYTE)ImageBase + dosHeader->e_lfanew);

	if (ntHeader->Signature != IMAGE_NT_SIGNATURE) {
		SetLastError(ERROR_INVALID_PE_FILE);
		return NULL;
	}

	return ntHeader;

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	} __except(EXCEPTION_EXECUTE_HANDLER) {
		SetLastError(ERROR_EXCEPTION_OCCURED);
		return NULL;
	}
	#endif // PEIMAGE_DONT_USE_EXCEPTION_HANDLING
}

//TBDTBD
PVOID WINAPI PeImageDirectoryEntryToDataEx(PVOID Base, BOOLEAN MappedAsImage, USHORT DirectoryEntry, PULONG Size, PIMAGE_SECTION_HEADER* FoundHeader)
{
	//TBDTBD: ERROR_CALL_NOT_IMPLEMENTED
	 return ImageDirectoryEntryToDataEx(Base, MappedAsImage, DirectoryEntry, Size, FoundHeader);
}



/*
	The PeImageGetNewSectionInformation function returns information about where a new section would be appended.
	Sometimes the size of a new section is unknown, but its RVA must be known to perform calculations. Use
	PeImageGetNewSectionInformation to obtain the raw offset and RVA of a new section that you which to append to an
	image.

	Parameters
	----------
	[in] NtHeaders: Pointer to an IMAGE_NT_HEADERS structure
	[out] pNewSectionInfo: Partially completed IMAGE_SECTION_HEADER structure. RawOffset & RVA are there

	Return Values
	-------------
	Success: the Rva of the new section along with the structure pNewSectionInfo.
	Error: -1
*/
DWORD WINAPI PeImageGetNewSectionInformation(PIMAGE_NT_HEADERS NtHeaders, PIMAGE_SECTION_HEADER pNewSectionInfo)
{
	PIMAGE_SECTION_HEADER	pLastSection;
	DWORD		sectionEndRva, sectionEndRaw, sectionAlignment, fileAlignment;

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	__try {
	#endif

	if ((pLastSection = PeImageGetLastSection(NtHeaders))==NULL) {
		// LastError given by callee
		return -1;
	}

	sectionEndRva = pLastSection->VirtualAddress + pLastSection->Misc.VirtualSize;
	sectionEndRaw = pLastSection->PointerToRawData + pLastSection->SizeOfRawData;
	fileAlignment = NtHeaders->OptionalHeader.FileAlignment;
	sectionAlignment = NtHeaders->OptionalHeader.SectionAlignment;

	if ((sectionEndRva % sectionAlignment)!=0) {
		// This means that the VirtualSize was not aligned to the ceiling section aligned address.
		// Align it.
		sectionEndRva = (1 + (sectionEndRva / sectionAlignment))*sectionAlignment;
	}

	if ((sectionEndRaw % fileAlignment)!=0) {
		// This means that the SizeOfRawData was not aligned to the ceiling file aligned address
		// Align it
		sectionEndRaw = (1 + (sectionEndRaw / fileAlignment))*fileAlignment;
	}
	
	pNewSectionInfo->VirtualAddress = sectionEndRva;
	pNewSectionInfo->PointerToRawData = sectionEndRaw;

	return	sectionEndRva;

	#ifndef  PEIMAGE_DONT_USE_EXCEPTION_HANDLING
	} __except(EXCEPTION_EXECUTE_HANDLER) {
		SetLastError(ERROR_EXCEPTION_OCCURED);
		return -1;
	}
	#endif // PEIMAGE_DONT_USE_EXCEPTION_HANDLING
}