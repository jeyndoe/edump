// header for handlers.cpp
// (c) doug
#ifndef HANDLERS_H
#define HANDLERS_H


enum	X86_REGISTERS {
	REG_EAX=0,
	REG_ECX,
	REG_EDX,
	REG_EBX,
	REG_ESP,
	REG_EBP,
	REG_ESI,
	REG_EDI
};

typedef struct _EVAL_MOV_LEA {

	IN  int		reg_num;
	IN	DWORD	reg_val;
	OUT	BYTE	block[5];
	OUT int		scale;
	OUT	int		index_reg;
	OUT int		imm;
} EVAL_MOV_LEA;


typedef struct _MEMOP {
	BOOL	valid;
	LPBYTE	location;
	DWORD	len;
	int		reg;
	LPBYTE	opcode;
	LPBYTE  replacement;
	DWORD	replacement_len;
	BYTE	backup_bytes[6];
	DWORD	constant;
	LPBYTE	ret_to;
} MEMOP;


const char* getRegisterString(int register_num);
const char* getJccString(int jccType);
int eat_nop(LPBYTE lp);
int reduce_mov_lea_sib_dwordptr_instructions(LPBYTE loc, EVAL_MOV_LEA* eml);

HRESULT srom_jmp_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_call_1(INPUT_HANDLING_FUNCTION* input);
HRESULT	srom_prolog_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_stack_read_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_addreg_const_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_jcc_1a(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_jcc_1b(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_addesp_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_subesp_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_addreg_imm_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_push_reg_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_pop_reg_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_test_reg_reg_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_movlea_reg_dword(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_cmp_dword(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_slice_1(INPUT_HANDLING_FUNCTION* input);
HRESULT	srom_epilog_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_ret(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_mov_reg_imm32(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_anti_trace_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_push_offset_1(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_push_offset_2(INPUT_HANDLING_FUNCTION* input);
HRESULT srom_mov_reg_imm32_2(INPUT_HANDLING_FUNCTION* input);
#endif //HANDLERS_H