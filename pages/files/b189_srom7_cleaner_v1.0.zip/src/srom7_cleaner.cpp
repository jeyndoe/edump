/*	srom7_cleaner.cpp

	Cleans code that was protected/obfuscated with SecuROM's code obfuscator.
	While this tool handles a LOT of things, it is not perfect, so don't 
	expect to be able to run files that were cleaned with it. The purpose
	of this tool is to simplify a reverse-engineering/security analysis
	of those binaries.

	This tools only supports PE image. Since starting with some version, 
	the securom .text section is compressed, just use LordPE to dump the 
	entire process (dump full) to disk at the point where the .init section 
	RET's to the real entrypoint in .text.


	April 2005 (c) doug

*/

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>

#include "srom7_cleaner.h"
#include "peImageHlp.h"
#include "sig_tracer.h"
#include "produce_code.h"
#include "handlers.h"

/*
	List of byte-patterns
	See handlers.cpp & the patterns[] array to see the code handling 
	those patterns.
	
	Creating a new pattern involves:
		- Creating an array with the signature bytes
		- [Optional] creating an array with the mask. No mask array means a 
		   mask of 0xFF is used, except for 0x0, which are the wildcard bytes.
		- Adding an entry in the "patterns" array.
		- Coding the handling function & adding the definition in the .h
*/
BYTE	pat_jcc_1a[]				= {0x68,00,00,00,00,0x70,00,0x81,0x04,0x24,00,00,00,00,0x81,0x04,0x24,00,00,00,00,0xEB,0xFA};
BYTE	pat_jcc_1a_mask[]			= {0xFF,00,00,00,00,0xF0,00,0xFF,0xFF,0xFF,00,00,00,00,0xFF,0xFF,0xFF,00,00,00,00,0xFF,0xFF};
BYTE	pat_jcc_1b[]				= {0x6A,00,00,00,0x81,0x04,0x24,00,00,00,00,0x81,0x04,0x24,00,00,00,00,0xEB,0xFA};
BYTE	pat_call_1[]				= {0x81,0x04,0x24,00,00,00,00,0xFF,0x34,0x24,0x81,0x2C,0x24,00,00,00,00,0xFF,0x34};
BYTE	pat_stack_read_1[]			= {0xB8,0,0,0,0,0x8B,0x84,0x00,0,0,0,0};
BYTE	pat_stack_read_1_mask[]		= {0xF8,0,0,0,0,0xFF,0xC7,0xC0,0,0,0,0};
BYTE	pat_add_esp_1[]				= {0xC7,0x04,0x24,0,0,0,0,0x81,0x34,0x24,0,0,0,0,0x03,0x24,0x24};
BYTE	pat_add_esp_1_s[]			= {0xC7,0x04,0x24,0,0,0,0,0x83,0x34,0x24,0,0x03,0x24,0x24};
BYTE	pat_mov_reg_dword[]			= {0xB8,0,0,0,0,0x8B,0x80,0,0,0,0};
BYTE	pat_mov_reg_dword_mask[]	= {0xF8,0,0,0,0,0xFF,0xC0,0,0,0,0};
BYTE	pat_lea_reg_dword[]			= {0xB8,0,0,0,0,0x8D,0x80,0,0,0,0};
BYTE	pat_lea_reg_dword_mask[]	= {0xF8,0,0,0,0,0xFF,0xC0,0,0,0,0};
BYTE	pat_mov_reg_imm32[]			= {0x68,0,0,0,0,0x81,0x34,0x24,0,0,0,0,0x58};
BYTE	pat_mov_reg_imm32_mask[]	= {0xFF,0,0,0,0,0xFF,0xFF,0xFF,0,0,0,0,0xF8};
BYTE	pat_mov_reg_imm32_s[]		= {0x6A,0x00,0x81,0x34,0x24,0,0,0,0,0x58};
BYTE	pat_mov_reg_imm32_s_mask[]	= {0xFF,0x00,0xFF,0xFF,0xFF,0,0,0,0,0xF8};
BYTE	pat_mov_reg_imm32_ss[]		= {0x6A,0x00,0x83,0x34,0x24,0,0x58};
BYTE	pat_mov_reg_imm32_ss_mask[]	= {0xFF,0x00,0xFF,0xFF,0xFF,0,0xF8};
BYTE	pat_mov_reg_imm32_2[]		= {0x8D,0x05,0,0,0,0,0x83,0xEC,0x04,0x89,0x04,0x24,0xB8,0,0,0,0,0x81,0xF0,0,0,0,0,0x29,0x04,0x24,0x58};
BYTE	pat_mov_reg_imm32_2_mask[]	= {0xFF,0xC5,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xC7,0xFF,0xF8,0,0,0,0,0xFF,0xF8,0,0,0,0,0xFF,0xC7,0xFF,0xF8};
BYTE	pat_epilog_1[]				= {0x8B,0xe5,0x8b,0x2c,0x24,0x83,0xc4,0x04,0xff,0x34,0x24};
BYTE	pat_ret_1[]					= {0xFF,0x34,0x24,0xC7,0x44,0x24,0x04,0,0,0,0,0xeb,0xfa};
BYTE	pat_anti_trace_1[]			= {0x50,0x16,0x17,0x9C,0x8B,0x04,0x24,0xF6,0xC4,0x01,0x74,0x05,0xB9,0xBE,0x07,0x00,0x00,0x33,0xC0,0x74,0x01,0xE8,0x9D,0x58};
BYTE	pat_push_offset_1[]			= {0x68,0x00,0x00,0x00,0x00,0x81,0x04,0x24,0x00,0x00,0x00,0x00};
BYTE	pat_push_offset_1_mask[]	= {0xFF,0x00,0x00,0x00,0x00,0xFF,0xC7,0xFF,0x00,0x00,0x00,0x00};
BYTE	pat_push_offset_1_s[]		= {0x6A,0x00,0x81,0x04,0x24,0x00,0x00,0x00,0x00};
BYTE	pat_push_offset_1_s_mask[]	= {0xFF,0x00,0xFF,0xC7,0xFF,0x00,0x00,0x00,0x00};
// these are all very similar patterns/masks
BYTE	pat_slice_1[]				= {0x9C,0x83,0xEC,0,0xC7,0x44,0x24,0,0,0,0,0,0xC7,0x44,0x24,0,0,0,0,0,0x89,0,0,0,0xB8,0,0,0,0,0xC1};
BYTE	pat_slice_1_mask[]			= {0xFF,0xFF,0xFF,0,0xFF,0xFF,0xFF,0,0,0,0,0,0xFF,0xFF,0xFF,0,0,0,0,0,0xFF,0,0,0,0xF8,0,0,0,0,0xFF};
BYTE	pat_jmp_1[]					= {0x83,0xec,0x04,0xC7,0x04,0x24,0,0,0,0,0x81,0x04,0x24,0,0,0,0,0xeb,0xfa};
BYTE	pat_prolog_1[]				= {0x83,0xEC,0x04,0x89,0x2C,0x24,0x8B,0xEC};
BYTE	pat_add_reg_const_1[]		= {0x83,0xEC,0,0xC7,0x44,0x24,0,0,0,0,0,0xC7,0x44,0x24,0,0,0,0,0,0x89,0,0,0,0xB8,0,0,0,0};
BYTE	pat_add_reg_const_1_mask[]	= {0xFF,0xFF,0,0xFF,0xFF,0xFF,0,0,0,0,0,0xFF,0xFF,0xFF,0,0,0,0,0,0xFF,0,0,0,0xF8,0,0,0,0};
BYTE	pat_sub_esp_1[]				= {0x83,0xEC,0x04,0xC7,0x04,0x24,0,0,0,0,0x81,0x34,0x24,0,0,0,0,0x2B,0x24,0x24};
BYTE	pat_addreg_imm_1[]			= {0x83,0xEC,0x04,0x89,0x04,0x24,0xB8,0,0,0xD1,0xE0,0x70,0xFC};
BYTE	pat_addreg_imm_1_mask[]		= {0xFF,0xFF,0xFF,0xFF,0xC7,0xFF,0xF8,0,0,0xFF,0xF8,0xF0,0xFF};
BYTE	pat_test_reg_reg[]			= {0x83,0xEC,0x04,0x89,0x04,0x24,0x8B,0xC0,0x23,0xC0,0x58};
BYTE	pat_test_reg_reg_mask[]		= {0xFF,0xFF,0xFF,0xFF,0xC7,0xFF,0xFF,0xC0,0xFF,0xC0,0xF8};
BYTE	pat_cmp_dword[]				= {0x83,0xEC,0x04,0x89,0x04,0x24,0x8B};
BYTE	pat_cmp_dword_mask[]		= {0xFF,0xFF,0xFF,0xFF,0xC7,0xFF,0xFF};
BYTE	pat_push_reg_1[]			= {0x83,0xEC,0x04,0x89,0x04,0x24};
BYTE	pat_push_reg_1_mask[]		= {0xFF,0xFF,0xFF,0xFF,0xC7,0xFF};
BYTE	pat_pop_reg_1[]				= {0x8B,0x04,0x24,0x83,0xC4,0x04};
BYTE	pat_pop_reg_1_mask[]		= {0xFF,0xC7,0xFF,0xFF,0xFF,0xFF};
BYTE	pat_push_offset_2[]			= {0x83,0xEC,0x04,0x89,0x04,0x24,0xB8,0,0,0,0,0x83,0xEC,0x04,0x89,0x04,0x24,0xB8,0,0,0,0,0x81,0xF0,0,0,0,0,0x29,0x04,0x24,0x58,0x87,0x04,0x24};
BYTE	pat_push_offset_2_mask[]	= {0xFF,0xFF,0xFF,0xFF,0xC7,0xFF,0xF8,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xC7,0xFF,0xF8,0,0,0,0,0xFF,0xF8,0,0,0,0,0xFF,0xC7,0xFF,0xF8,0xFF,0xC7,0xFF};
BYTE	pat_push_offset_2_s[]		= {0x83,0xEC,0x04,0x89,0x04,0x24,0xB8,0,0,0,0,0x83,0xEC,0x04,0x89,0x04,0x24,0xB8,0,0,0,0,0x83,0xF0,0,0x29,0x04,0x24,0x58,0x87,0x04,0x24};
BYTE	pat_push_offset_2_s_mask[]	= {0xFF,0xFF,0xFF,0xFF,0xC7,0xFF,0xF8,0,0,0,0,0xFF,0xFF,0xFF,0xFF,0xC7,0xFF,0xF8,0,0,0,0,0xFF,0xF8,0,0xFF,0xC7,0xFF,0xF8,0xFF,0xC7,0xFF};

// Note that the first element in the array gets scanned for first. 
// Use this wisely - it can be tricky.
DIRTY_PATTERN patterns[] = {
	// FriendlyName,	FUNCTION,				SIGNATURE,				SIG_SIZE						HAS_MASK	MASK						COUNTERS
	{ "Jmp",			srom_jmp_1,				pat_jmp_1,				sizeof(pat_jmp_1),				FALSE,		NULL						,0,0},
	{ "AddEsp",			srom_addesp_1,			pat_add_esp_1,			sizeof(pat_add_esp_1),			FALSE,		NULL						,0,0},
	{ "AddEsp s",		srom_addesp_1,			pat_add_esp_1_s,		sizeof(pat_add_esp_1_s),		FALSE,		NULL						,0,0},
	{ "SubEsp",			srom_subesp_1,			pat_sub_esp_1,			sizeof(pat_sub_esp_1),			FALSE,		NULL						,0,0},
	{ "AntiTrace",		srom_anti_trace_1,		pat_anti_trace_1,		sizeof(pat_anti_trace_1),		FALSE,		NULL						,0,0},
	{ "AddRegConst",	srom_addreg_const_1,	pat_add_reg_const_1,	sizeof(pat_add_reg_const_1),	TRUE,		pat_add_reg_const_1_mask	,0,0},
	{ "Slicer",			srom_slice_1,			pat_slice_1,			sizeof(pat_slice_1),			TRUE,		pat_slice_1_mask			,0,0},
	{ "Test reg/reg",	srom_test_reg_reg_1,	pat_test_reg_reg,		sizeof(pat_test_reg_reg),		TRUE,		pat_test_reg_reg_mask		,0,0},
	{ "Jcc 1a",			srom_jcc_1a,			pat_jcc_1a,				sizeof(pat_jcc_1a),				TRUE,		pat_jcc_1a_mask				,0,0},
	{ "Jcc 1b",			srom_jcc_1b,			pat_jcc_1b,				sizeof(pat_jcc_1b),				FALSE,		NULL						,0,0},
	{ "AddRegImm",		srom_addreg_imm_1,		pat_addreg_imm_1,		sizeof(pat_addreg_imm_1),		TRUE,		pat_addreg_imm_1_mask		,0,0},
	{ "Prolog",			srom_prolog_1,			pat_prolog_1,			sizeof(pat_prolog_1),			FALSE,		NULL						,0,0},
	{ "Epilog",			srom_epilog_1,			pat_epilog_1,			sizeof(pat_epilog_1),			FALSE,		NULL						,0,0},
	{ "StackRead",		srom_stack_read_1,		pat_stack_read_1,		sizeof(pat_stack_read_1),		TRUE,		pat_stack_read_1_mask		,0,0},
	{ "Call",			srom_call_1,			pat_call_1,				sizeof(pat_call_1),				FALSE,		NULL						,0,0},
	{ "MovRegImm32",	srom_mov_reg_imm32,		pat_mov_reg_imm32,		sizeof(pat_mov_reg_imm32),		TRUE,		pat_mov_reg_imm32_mask		,0,0},
	{ "MovRegDwordPtr",	srom_movlea_reg_dword,	pat_mov_reg_dword,		sizeof(pat_mov_reg_dword),		TRUE,		pat_mov_reg_dword_mask		,0,0},
	{ "LeaRegDwordPtr",	srom_movlea_reg_dword,	pat_lea_reg_dword,		sizeof(pat_lea_reg_dword),		TRUE,		pat_lea_reg_dword_mask		,0,0},
	// Keep Push Offset *after* MovRegImm32
	{ "Push Offset1",	srom_push_offset_1,		pat_push_offset_1,		sizeof(pat_push_offset_1),		TRUE,		pat_push_offset_1_mask		,0,0},
	{ "Push Offset2",	srom_push_offset_2,		pat_push_offset_2,		sizeof(pat_push_offset_2),		TRUE,		pat_push_offset_2_mask		,0,0},
	{ "Push Offset2s",	srom_push_offset_2,		pat_push_offset_2_s,	sizeof(pat_push_offset_2_s),	TRUE,		pat_push_offset_2_s_mask	,0,0},
	{ "MovRegImm32_2",	srom_mov_reg_imm32_2,	pat_mov_reg_imm32_2,	sizeof(pat_mov_reg_imm32_2),	TRUE,		pat_mov_reg_imm32_2_mask	,0,0},
	// keep Cmp *after* test reg reg
	//{ "Cmp dwordPtr",	srom_cmp_dword,			pat_cmp_dword,			sizeof(pat_cmp_dword),			TRUE,		pat_cmp_dword_mask			,0,0},
	// keep PushReg *last* (it is a substring of another)
	{ "PushReg",		srom_push_reg_1,		pat_push_reg_1,			sizeof(pat_push_reg_1),			TRUE,		pat_push_reg_1_mask			,0,0},
	{ "Ret",			srom_ret,				pat_ret_1,				sizeof(pat_ret_1),				FALSE,		NULL						,0,0},
	{ "PopReg",			srom_pop_reg_1,			pat_pop_reg_1,			sizeof(pat_pop_reg_1),			TRUE,		pat_pop_reg_1_mask			,0,0},
	{ "MovRegImm32s",	srom_mov_reg_imm32,		pat_mov_reg_imm32_s,	sizeof(pat_mov_reg_imm32_s),	TRUE,		pat_mov_reg_imm32_s_mask	,0,0},
	{ "MovRegImm32ss",	srom_mov_reg_imm32,		pat_mov_reg_imm32_ss,	sizeof(pat_mov_reg_imm32_ss),	TRUE,		pat_mov_reg_imm32_ss_mask	,0,0},
	{ "Push Offset1 s",	srom_push_offset_1,		pat_push_offset_1_s,	sizeof(pat_push_offset_1_s),	TRUE,		pat_push_offset_1_s_mask	,0,0},
};

const int pattern_count	= sizeof(patterns)/sizeof(DIRTY_PATTERN);



/*
	Scans for a pattern inside a PE image code section (this is an important 
	assumption with consequences to keep in mind)

	Tries each pattern signature in the patterns array.
*/
void scan_section_for_patterns(LPVOID ImageStart, LPBYTE SectionBase, DWORD size, LPVOID VirginImageStart)
{
	DWORD	success_flag=0, found_location=0;

	DWORD	seek_head = 0;
	HRESULT	hr;

	DWORD	ImageBase = PeImageNtHeader(ImageStart)->OptionalHeader.ImageBase;

	printf("\n");

	for (int i=0; i < pattern_count; i++) {
		seek_head=0;
		success_flag=0;

		LPBYTE pMask = NULL;
		if (patterns[i].has_mask) {
			pMask = patterns[i].mask;
		}
		found_location = signature_tracer(SectionBase, size, patterns[i].sig, pMask, patterns[i].sig_size, &success_flag);

		while (success_flag!=0) {
			seek_head += found_location;

			INPUT_HANDLING_FUNCTION	input;

			input.imageBase = ImageBase;
			input.imageStart = ImageStart;
			input.virginImageStart = VirginImageStart;
			input.pat_match_start = SectionBase + seek_head;
			input.size_left = size - seek_head;
			input.pat_size = patterns[i].sig_size;


			// get "SectionBase-ImageStart" RAW->RVA
			DWORD	rawOff = (LPBYTE)input.pat_match_start - (LPBYTE)ImageStart;
			DWORD	rva = PeImageRawOffsetToRVA( PeImageNtHeader(ImageStart), ImageStart, rawOff, TRUE);

			input.pat_match_delta = rva + ImageBase - (DWORD)input.pat_match_start;

			hr = E_FAIL;
			if (patterns[i].function != NULL) {
				printf(" %s: ", patterns[i].FriendlyName);
				printf("%X ", (LPBYTE)input.pat_match_start + input.pat_match_delta);
				hr = patterns[i].function(&input);
			}

			if (FAILED(hr)) {
				printf("Found '%s', but its function failed\n", patterns[i].FriendlyName);
				seek_head++;
				patterns[i].failed_count++;
			}
			else {
				seek_head += patterns[i].sig_size;
				patterns[i].fixed_count++;
			}

			found_location = signature_tracer(SectionBase + seek_head, size - seek_head, patterns[i].sig, pMask, patterns[i].sig_size, &success_flag);
		} // end while

		printf("-------- End of '%s' scan -------- \n\n", patterns[i].FriendlyName );
	} // end for

}


/*
	Scan for a pattern inside a PE-Image.

	This function finds individual sections and asks the user to scan it.
*/
void scan_for_patterns(LPVOID input_base, DWORD RawSize, LPVOID VirginImageStart)
{

	PIMAGE_SECTION_HEADER pSection;
	DWORD i=0, sectionSize=0;

	PIMAGE_NT_HEADERS NtHeaders = PeImageNtHeader(input_base);

	if (NtHeaders==NULL) {
		printf("Error, not PE file\n");
		return;
	}

	pSection = (PIMAGE_SECTION_HEADER) (((LPBYTE)&NtHeaders->OptionalHeader) + NtHeaders->FileHeader.SizeOfOptionalHeader);

	while (i < NtHeaders->FileHeader.NumberOfSections) {
	
		char	sectionName[9];
		strncpy(sectionName, (char*)pSection->Name, sizeof(sectionName));
		sectionName[8]='\0';

		int	choice =0;
		bool do_scan=false;
		while ( choice == 0 ) {

			fflush(stdout);
			//printf("[?] Scan section #%d/%d, named '%s', %d bytes? (y/n/q)  .. ", i+1, NtHeaders->FileHeader.NumberOfSections, sectionName, pSection->SizeOfRawData);
			fprintf(stderr, "[?] Scan section #%3d/%-3d, named '%-8s', %8d bytes? (y/n/q)  .. ", i+1, NtHeaders->FileHeader.NumberOfSections, sectionName, pSection->SizeOfRawData);
			
			fflush(stdin);
			choice=getchar();
			if (choice=='y' || choice=='Y') {
				do_scan=true;
			}
			else if (choice=='n' || choice=='N') {
				do_scan=false;
			}
			else if (choice=='q' || choice=='Q') {
				printf("    Leaving\n");
				goto LCleanupScan;
			}
			else {
				choice=0;
			}
		}

		if (do_scan) {
			scan_section_for_patterns(input_base, (LPBYTE)input_base+pSection->PointerToRawData, pSection->SizeOfRawData, VirginImageStart);
			printf("\n\n");
		}
		else {
			printf("    Skipping section.\n");
		}

		pSection++;
		i++;
	}
LCleanupScan:
	return;
}


BOOL file_open(char *buf, int bufSize)
{
	OPENFILENAME	ofn;

	memset(&ofn, 0, sizeof(OPENFILENAME));

	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = NULL;
	ofn.lpstrFilter = 
		"Executable (*.exe)\0*.exe\0\
		All types (*.*)\0*.*\0\0";

	ofn.lpstrTitle = "Select the file";
	ofn.nMaxFile = bufSize;
	ofn.lpstrFile = buf;
	ofn.Flags = OFN_FILEMUSTEXIST;

	return GetOpenFileName(&ofn);
}


int main(int argc, char **argv)
{
	HANDLE	in_hFile, in_hMapFile;
	LPVOID	in_image_file;
	char	filename[MAX_PATH];


	printf("=============================================\n");
	printf("==      *    SecuROM v7 Cleaner      *     ==\n");
	printf("==                                         ==\n");
#ifdef _DEBUG
	printf("==          %s-%s-d         ==\n",__DATE__,__TIME__);
#else
	printf("==          %s-%s           ==\n",__DATE__,__TIME__);
#endif
	printf("==                                         ==\n");
	printf("==                  by                     ==\n");
	printf("==                 doug                    ==\n");
	printf("=============================================\n\n");


	printf("=============================================\n");
	printf("==                  Tips                   ==\n");
	printf("=============================================\n");
	printf(" * If this is the first scan of the file,    \n");
	printf("   you should only scan .init                \n");
	printf("\n");
	printf(" * Sometimes, executing this program twice   \n");
	printf("   will give added results. (Due to the order\n");
	printf("   in which the patterns are scanned)        \n");
	printf("\n");
	printf(" * Failure Count of 'AddRegConst' normally   \n");
	printf("   equals 'Slicer' fixed count   :)          \n");
	printf("\n");
	printf("=============================================\n\n");

	filename[0]=0;

	if (argc>1) {
		printf("[i] CommandLine Mode\n");
		strncpy(filename, argv[1], sizeof(filename));
		filename[sizeof(filename)-1]=0;
	}
	else {
		printf("[i] Waiting for file selection ... ");
		if (!file_open(filename, sizeof(filename))) {
			return 0;
		}
		printf("ok\n");
	}

	printf("Copying input file ... ");

	char* backup_name = new char[strlen(filename) + 25];
	strcpy(backup_name, filename);
	strcat(backup_name, ".fixed.exe");
	if (CopyFile(filename, backup_name, FALSE)==0) {
		printf("Failed to create a copy\n");
		return 0;
	}

	printf("done\n\n");

	if ((in_hFile = CreateFile(backup_name, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL))==INVALID_HANDLE_VALUE) {
		printf("Error opening file %s. LastError=%8X\n", backup_name, GetLastError());
		return 0;
	}

	if ((in_hMapFile = CreateFileMapping(in_hFile, NULL, PAGE_READWRITE, 0, 0, NULL))==NULL) {
		printf("Error creating a mapping of the file\n");
		return 0;
	}
	if ((in_image_file=MapViewOfFile(in_hMapFile, FILE_MAP_WRITE, 0, 0, 0))==NULL) {
		printf("Unable to MapViewOfFile\n");
		return 0;
	}

	DWORD	fileSize = GetFileSize(in_hFile, NULL);

	LPVOID VirginImageStart = VirtualAlloc(NULL, fileSize, MEM_COMMIT, PAGE_READWRITE);
	memcpy(VirginImageStart, in_image_file, fileSize);

	scan_for_patterns(in_image_file, fileSize, VirginImageStart);

	FlushViewOfFile(in_image_file, 0);
	UnmapViewOfFile(in_image_file);
	CloseHandle(in_hMapFile);
	CloseHandle(in_hFile);
	VirtualFree(VirginImageStart, 0, MEM_RELEASE);

	int		global_counter_fixed = 0, global_counter_failed=0, global_counter_failed_ok=0;

	printf("\n\n");
	printf("=================================================\n");
	printf("==                  Scan Report                ==\n");
	printf("=================================================\n");
	for (int i=0; i < pattern_count; i++) {
		printf("%-20s: Fixed: %5d, Failed: %5d\n", patterns[i].FriendlyName, patterns[i].fixed_count, patterns[i].failed_count );
		global_counter_fixed += patterns[i].fixed_count;
		global_counter_failed += patterns[i].failed_count;
		if (0 != memcmp(patterns[i].sig, pat_add_reg_const_1, sizeof(pat_add_reg_const_1))) {
			global_counter_failed_ok += patterns[i].failed_count;
		}
	}
	printf("=================================================\n");
	printf("Total fixed:  %d\n", global_counter_fixed);
	printf("Total failed: %d\n", global_counter_failed);
	printf("Failure rate: %.2f%%\n", 100 * (float)global_counter_failed / (float)global_counter_fixed);
	printf("\n");
	printf("Without AddRegConst acceptable errors:\n");
	printf("Total failed: %d\n", global_counter_failed_ok);
	printf("Failure rate: %.2f%%\n", 100 * (float)global_counter_failed_ok / (float)global_counter_fixed);
	printf("=================================================\n\n");

	printf("Wrote: '%s'\n", backup_name);
	SAFE_DELETE_ARRAY(backup_name);

	fflush(stdin);
	fflush(stdout);
	fprintf(stderr, "Paused, press enter to terminate ...");
	getchar();
	printf("\n");
	return 0;
}