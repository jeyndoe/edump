/*
	sig_tracer.cpp

	Traces patterns of code using a Pattern & Mask

	Apr-14-2005

  (c) doug

  */
#include <windows.h>
#include "sig_tracer.h"


/* skips 0's in pattern */
int nullskipper(BYTE* pat, BYTE* mask, DWORD pat_l)
{
	DWORD i=0;

	while (i<pat_l) {
		if (mask!=NULL && mask[i]!=0) {
			break;
		}
		if (pat[i]!=0) {
			break;
		}
		i++;
	}
	return i;
}

/*
	bStart, bSize: define where to seach
	pattern, pattern_length: define what to search
	fflag: found flag. 1 if pattern was found.

  return value: offset from beginning of buffer to start of pattern. 
	*only* meaningful if fflag is 1.

*/
DWORD signature_tracer (BYTE* bStart, DWORD bSize, BYTE* pattern, BYTE* mask, DWORD pattern_length, DWORD* fflag)
{
	DWORD s_i=0, p_i=0, t=0, s_i_bak=0;
	BYTE maskByte;
	BYTE* pMask;
	*fflag=0;

	while (s_i<bSize && (bSize-s_i)>pattern_length)
		/* not at EOF, remaining size bigger than pat. length */
	{
		pMask=NULL;
		if (mask!=NULL) {
			pMask=mask;
		}
		s_i_bak=s_i;
		p_i=0;
		t=nullskipper(pattern, pMask, pattern_length); // in case pattern starts w/ 0.
		s_i+=t;
		p_i+=t;

		while (p_i < pattern_length) {
			if (mask==NULL) {
				maskByte = 0xFF;
			}
			else {
				maskByte = mask[p_i];
			}

			if ( (bStart[s_i]&maskByte) != pattern[p_i] ) {
				break;
			}
			s_i++;
			p_i++;
			if (p_i == pattern_length) {
				// got match here!
				break; //kick out of inner loop
			}

			if (mask!=NULL) {
				pMask = mask+p_i;
			}
			t=nullskipper(pattern+p_i, pMask, pattern_length - p_i);
			s_i+=t;
			p_i+=t;
		}
		if (p_i == pattern_length)
			break; // kick out of outer loop

		s_i = s_i_bak + 1; /* continue on next byte */

	}


	if (p_i == pattern_length) {
		/* return offset from start of bStart to the beginning of pattern */
		*fflag=1;
		return s_i-p_i;

	}
	else {
		return 0;
	}

}