// header for srom7_cleaner.cpp
// (c) doug
#ifndef SROM7_CLEANER_H
#define SROM7_CLEANER_H

typedef struct _INPUT_HANDLING_FUNCTION
{
	LPVOID	pat_match_start;		// in-mem location (RAW) of a match to the pattern.
	DWORD	pat_match_delta;		// location given RAW + pat_match_delta = location given VA
	DWORD	pat_size;				// size of the matched pattern
	DWORD	size_left;				// size left in this section. size_left >= pat_size
	DWORD	imageBase;
	LPVOID	imageStart;
	LPVOID	virginImageStart;
} INPUT_HANDLING_FUNCTION;


typedef HRESULT(*HANDLING_FUNCTION_1)(INPUT_HANDLING_FUNCTION*);


typedef struct _DIRTY_PATTERN {
	char*	FriendlyName;
	HANDLING_FUNCTION_1 function;
	BYTE*	sig;
	DWORD	sig_size;
	DWORD	has_mask;
	BYTE*	mask;
	DWORD	fixed_count;
	DWORD	failed_count;
} DIRTY_PATTERN;


#define	SAFE_DELETE(a)			{if (a) { delete a; a=NULL; }}
#define SAFE_DELETE_ARRAY(p)	{if (p) { delete[] p; p=NULL;}}


#endif //SROM7_CLEANER_H