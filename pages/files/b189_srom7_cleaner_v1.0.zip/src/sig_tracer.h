// header for sig_tracer.cpp
// (c) doug
#ifndef SIG_TRACER_H
#define SIG_TRACER_H

DWORD signature_tracer (BYTE* bStart, DWORD bSize, BYTE* pattern, BYTE* mask, DWORD pattern_length, DWORD* fflag);

#endif //SIG_TRACER_H