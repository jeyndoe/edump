/*
	handlers.cpp

	This file contains all the functions that handle the various 
	obfuscation patterns.

	All functions return a HRESULT, and accept a INPUT_HANDLING_FUNCTION* 
	parameter.

	The code here is pretty dense & hardcore to follow unless you have already 
	played with a target EXE.

	Some handlers modify their target code but leaves them in a friendly way 
	for another pattern handler. SecuROM's tool is a multi-pass, sometimes 
	parts of code have received several mods on top of each others.


	TBDTBD:
		- Improve srom_cmp_dword
		- Does sub esp have a short form?

	2005 (c) doug
*/
#include <windows.h>
#include <stdio.h>
#include <cassert>

#include "produce_code.h"
#include "srom7_cleaner.h"
#include "handlers.h"
#include "peImageHlp.h"
#include "ADE32.HPP"


char *registers_name[] = { "eax", "ecx", "edx", "ebx", "esp", "ebp", "esi", "edi" };
char *jcc_names[] = { "JO", "JNO", "JB", "JNB", "JE", "JNE", "JBE", "JA", "JS", "JNS", "JPE", "JPO", "JL", "JGE", "JLE", "JG" };

LPBYTE	executePage;
LPVOID	executePageStack=NULL;
LPVOID	oldStack=NULL;
LPVOID	exitStack=NULL;
LPVOID	entryStack=NULL;
DWORD	stack_size=0;
MEMOP	memop;

/*
==========================================================================
                             CMP dword ptr [dword_DB1C28], 0
==========================================================================
00BB1914 83 EC 04                             sub     esp, 4
00BB1917 89 1C 24                             mov     [esp], ebx
00BB191A 8B 1D 28 1C DB 00                    mov     ebx, dword_DB1C28
00BB1920 83 EB 00                             sub     ebx, 0
00BB1923 5B                                   pop     ebx


==========================================================================
                             CMP edx, 5A4Dh
==========================================================================
00C8C045 83 EC 04                                sub     esp, 4
00C8C048 89 1C 24                                mov     [esp], ebx
00C8C04B 8B DA                                   mov     ebx, edx
00C8C04D 81 EB 4D 5A 00 00                       sub     ebx, 5A4Dh
00C8C053 5B                                      pop     ebx


==========================================================================
                             CMP dword ptr [edx], 4550h
==========================================================================
00C8C0E3 83 EC 04                                sub     esp, 4
00C8C0E6 89 2C 24                                mov     [esp], ebp
00C8C0E9 8B 2A                                   mov     ebp, [edx]
00C8C0EB 81 ED 50 45 00 00                       sub     ebp, 4550h
00C8C0F1 5D                                      pop     ebp

==========================================================================
                             CMP dword ptr [edx+2C2h], 4062901h
==========================================================================
00C8CA32 83 EC 04                                sub     esp, 4
00C8CA35 89 1C 24                                mov     [esp], ebx
00C8CA38 8B 9A C2 02 00 00                       mov     ebx, [edx+2C2h]
00C8CA3E 81 EB 01 29 06 04                       sub     ebx, 4062901h
00C8CA44 5B                                      pop     ebx

==========================================================================
                             CMP dword ptr [ebp-10h], 0
==========================================================================
00C8C41A 83 EC 04                                sub     esp, 4
00C8C41D 89 14 24                                mov     [esp], edx
00C8C420 8B 55 F0                                mov     edx, [ebp-10h]
00C8C423 83 EA 00                                sub     edx, 0
00C8C426 5A                                      pop     edx

==========================================================================
                             CMP dword ptr [ebp-4], eax
==========================================================================
00C8CAFF 83 EC 04                                sub     esp, 4
00C8CB02 89 3C 24                                mov     [esp], edi
00C8CB05 8B 7D FC                                mov     edi, [ebp-4]
00C8CB08 2B F8                                   sub     edi, eax
00C8CB0A 5F                                      pop     edi
*/
HRESULT srom_cmp_dword(INPUT_HANDLING_FUNCTION* input)
{
	const	int		LHS_REG1	= 7;
	const	int		LHS_REG1_MASK= 0x7;
	const	int		LHS_IMM_OFF = 0x8;
	const	int		LHS_CMP_TYPE_OFF = 7;
	const	int		LHS_CMP_TYPE_MASK = 0xC0;
	bool	lhs_has_imm=false;
	bool	lhs_has_reg1=false;
	bool	rhs_has_reg1=false;
	bool	lhs_dword_ptr=true;
	bool	rhs_dword_ptr=false;
	signed int	lhs_imm=0;
	int		lhs_reg1=0;
	DWORD	lhs_instr_size=0;

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	// First analyze the LHS of the comparison
	BYTE	lhs_cmp_type = decode_at[LHS_CMP_TYPE_OFF];

	switch ((lhs_cmp_type & LHS_CMP_TYPE_MASK)>>6) {
	case 0:
		lhs_reg1 = (decode_at[LHS_REG1]&LHS_REG1_MASK);

		if (lhs_reg1==REG_ESP) {
			// MOV  REG1, [REG2+REG3*NN+IMM8]
			printf("Unhandled extension (lhs) ");
			return E_FAIL;
		}
		else if (lhs_reg1==REG_EBP) {
			// MOV  REG1, dword ptr [imm32]
			lhs_instr_size=6;
			lhs_has_imm=true;
			lhs_dword_ptr=true;
			lhs_imm =  *((signed int*)(decode_at+2));
			lhs_has_reg1=false;
		}
		else {
			// MOV	REG1, [REG2]
			lhs_has_imm = false;
			lhs_dword_ptr=true;
			lhs_has_reg1=true;
			lhs_instr_size = 2;
		}
		break;

	case 1:
		// MOV	REG1, [REG2+imm8]
		// MOV	REG1, [REG2+REG3*N+imm8]
		lhs_has_imm = true;
		lhs_has_reg1=true;
		lhs_dword_ptr=true;
		lhs_reg1 = (decode_at[LHS_REG1]&LHS_REG1_MASK);
		lhs_imm = (signed int)sign_extend_8(decode_at[LHS_IMM_OFF]);

		if (lhs_reg1 == REG_ESP) {
			lhs_instr_size=4;
			printf("Unhandled extension (lhs) ");
			return E_FAIL;
		}
		else {
			lhs_instr_size = 3;
		}

		break;

	case 2:
		// MOV	REG1, [REG2+imm32]
		// MOV	REG1, [REG2+REG3*N+imm32]	
		lhs_has_imm = true;
		lhs_has_reg1=true;
		lhs_dword_ptr=true;
		lhs_reg1 = (decode_at[LHS_REG1]&LHS_REG1_MASK);
		lhs_imm = *((signed int*)(decode_at+LHS_IMM_OFF));

		if (lhs_reg1 == REG_ESP) {

			lhs_instr_size=7;
			printf("Unhandled extension");
			return E_FAIL;
		}
		else {
			lhs_instr_size=6;
		}

		break;

	case 3:
		// MOV	REG1, REG2
		lhs_has_imm = false;
		lhs_dword_ptr = false;
		lhs_reg1 = (decode_at[LHS_REG1]&LHS_REG1_MASK);

		lhs_instr_size = 2;
		break;

	default:
		return E_FAIL;
		break;
	}

	bool	rhs_has_imm=false;
	int		rhs_reg1=0;
	signed int	rhs_imm=0;
	DWORD	rhs_instr_size=0;

	// Now, analyze the RHS of the comparison.
	LPBYTE	rhs_instr = decode_at + (LHS_CMP_TYPE_OFF-1) + lhs_instr_size;
	BYTE	rhs_cmp_type = *rhs_instr;
	
	switch (rhs_cmp_type) {
	case 0x83:
		// SUB	REG1, imm8
		if ((rhs_instr[1]&0xF8) != 0xE8) {
			printf("Unhandled instruction (rhs) ");
			return E_FAIL;
		}
		rhs_has_imm=true;
		rhs_imm = (signed int) sign_extend_8(rhs_instr[2]);
		rhs_instr_size=3;
		break;

	case 0x81:
		// SUB	REG1, imm32
		if ((rhs_instr[1]&0xF8) != 0xE8) {
			printf("Unhandled instruction (rhs) ");
			return E_FAIL;
		}
		rhs_has_imm=true;
		rhs_imm = *((signed int*)(rhs_instr+2));
		rhs_instr_size=6;
		break;

	case 0x2B:
		//SUB	REG1, [REG2]
		//SUB	REG1, [REG2+imm8]
		//SUB	REG1, [REG2+imm32]
		//SUB	REG1, REG2

		switch((rhs_instr[1]&0xC0)>>6) {
		case 0:
			//SUB	REG1, [REG2]
			rhs_reg1 = (rhs_instr[1]&0x7);
			rhs_has_reg1=true;
			rhs_has_imm=false;
			rhs_instr_size=2;
			rhs_dword_ptr=true;
			break;

		case 1:
			//SUB	REG1, [REG2+imm8]
			rhs_reg1 = (rhs_instr[1]&0x7);
			rhs_has_reg1=true;
			rhs_has_imm=true;
			rhs_instr_size=3;
			rhs_dword_ptr=true;
			rhs_imm=sign_extend_8(rhs_instr[2]);
			break;

		case 2:
			//SUB	REG1, [REG2+imm32]
			rhs_reg1 = (rhs_instr[1]&0x7);
			rhs_has_reg1=true;
			rhs_has_imm=true;
			rhs_instr_size=6;
			rhs_dword_ptr=true;
			rhs_imm=*((DWORD*)(rhs_instr+2));
			break;

		case 3:
			//SUB	REG1, REG2
			rhs_reg1 = (rhs_instr[1]&0x7);
			rhs_has_reg1=true;
			rhs_has_imm=false;
			rhs_instr_size=2;
			rhs_dword_ptr=false;
			break;

		default:
			printf("Unhandled instruction (rhs)");
			return E_FAIL;
		}

		break;

	default:
		return E_FAIL;
		break;
	}

	injectNop(decode_at, LHS_CMP_TYPE_OFF - 1 + rhs_instr_size + lhs_instr_size + 1);

	char	cmp_str[200];
	injectCmp(decode_at, lhs_reg1, lhs_has_reg1, lhs_imm, lhs_has_imm, rhs_reg1, rhs_has_reg1, rhs_imm, rhs_has_imm, lhs_dword_ptr, rhs_dword_ptr, cmp_str, sizeof(cmp_str));

	printf("%s\n", cmp_str);
	return S_OK;
}



/* TEST REG, REG
==========================================================================
                             test eax, eax
==========================================================================
00C8C9C4 83 EC 04                                sub     esp, 4
00C8C9C7 89 3C 24                                mov     [esp], edi
00C8C9CA 8B F8                                   mov     edi, eax
00C8C9CC 23 F8                                   and     edi, eax
00C8C9CE 5F                                      pop     edi
*/
HRESULT srom_test_reg_reg_1(INPUT_HANDLING_FUNCTION* input)
{
	const	int		REG1_OFF		= 0x7;
	const	int		REG2_OFF		= 0x9;
	BYTE	test_reg_reg[] = { 0x85, 0xC0 };

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	BYTE	reg1 = (decode_at[REG1_OFF]&0x7);
	BYTE	reg2 = (decode_at[REG2_OFF]&0x7);

	if (reg1!=reg2) {
		return E_FAIL;
	}

	test_reg_reg[1] = test_reg_reg[1] | (reg1<<3) | reg1;

	injectNop(decode_at, 0xB);
	memcpy(decode_at, test_reg_reg, sizeof(test_reg_reg));

	printf("  TEST  %s, %s\n", getRegisterString(reg1),getRegisterString(reg1));


	return S_OK;
}

/*
==========================================================================
                             PUSH ECX
==========================================================================
00C8CBA9 83 EC 04                                sub     esp, 4
00C8CBAC 89 0C 24                                mov     [esp], ecx
*/
HRESULT srom_push_reg_1(INPUT_HANDLING_FUNCTION* input)
{
	const	int		REG_OFF		= 0x4;
	const	int		SAFE_CHECK_OFF	 = 0x6;
	BYTE	push_reg[] = { 0x50 };

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	BYTE	reg = (decode_at[REG_OFF]&0x38)>>3;
	push_reg[0] |= reg;

	if ((decode_at[SAFE_CHECK_OFF]&0xF8)==0xB8) {
		printf(" *Warn* Pattern Collapse ");
	}

	injectNop(decode_at, 0x6);
	memcpy(decode_at, push_reg, sizeof(push_reg));

	printf("  PUSH  %s\n", getRegisterString(reg));

	return S_OK;
}



/*
==========================================================================
                             POP EDI
==========================================================================
00811433 8B 3C 24                             mov     edi, [esp]
00811436 83 C4 04                             add     esp, 4

==========================================================================
                             POP ESI
==========================================================================
00811439 8B 34 24                             mov     esi, [esp]
0081143C 83 C4 04                             add     esp, 4

*/
HRESULT srom_pop_reg_1(INPUT_HANDLING_FUNCTION* input)
{
	const	int		REG_OFF		= 0x1;
	const	int		SAFE_CHECK_OFF	 = 0x6;
	BYTE	pop_reg[] = { 0x58 };

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	BYTE	reg = (decode_at[REG_OFF]&0x38)>>3;
	pop_reg[0] |= reg;

	if ((decode_at[SAFE_CHECK_OFF]&0xF8)==0xB8) {
		printf(" *Warn* Pattern Collapse ");
	}

	injectNop(decode_at, 0x6);
	memcpy(decode_at, pop_reg, sizeof(pop_reg));

	printf("  POP  %s\n", getRegisterString(reg));

	return S_OK;
}



/*
==========================================================================
                             ADD ECX,1
==========================================================================
00C8C815 83 EC 04                                sub     esp, 4
00C8C818 89 0C 24                                mov     [esp], ecx
00C8C81B                         
00C8C81B                         loc_C8C81B:                             ; CODE XREF: 0000:00C8C820.j
00C8C81B B9 B4 00 D1 E1                          mov     ecx, 0E1D100B4h
00C8C820 73 FC                                   jnb     short near ptr loc_C8C81B+3
00C8C822 81 F1 69 01 A2 C3                       xor     ecx, 0C3A20169h
00C8C828 01 0C 24                                add     [esp], ecx
00C8C82B 59                                      pop     ecx

==========================================================================
                             ADD EAX,1
==========================================================================
00C8D16C 83 EC 04                                sub     esp, 4
00C8D16F 89 04 24                                mov     [esp], eax
00C8D172                         
00C8D172                         loc_C8D172:                             ; CODE XREF: 0000:00C8D177.j
00C8D172 B8 2B 08 D1 E0                          mov     eax, 0E0D1082Bh
00C8D177 73 FC                                   jnb     short near ptr loc_C8D172+3
00C8D179 35 57 10 A2 C1                          xor     eax, 0C1A21057h
00C8D17E 01 04 24                                add     [esp], eax
00C8D181 58                                      pop     eax

==========================================================================
                             ADD ECX,8
==========================================================================
00C02103 83 EC 04                             sub     esp, 4
00C02106 89 0C 24                             mov     [esp], ecx
00C02109                      
00C02109                      loc_C02109:                             ; CODE XREF: 0000:00C0210E.j
00C02109 B9 97 00 D1 E1                       mov     ecx, 0E1D10097h
00C0210E 73 FC                                jnb     short near ptr loc_C02109+3
00C02110 81 F1 26 01 A2 C3                    xor     ecx, 0C3A20126h
00C02116 01 0C 24                             add     [esp], ecx
00C02119 59                                   pop     ecx
*/
HRESULT srom_addreg_imm_1(INPUT_HANDLING_FUNCTION* input)
{
	const	int		MAGIC1_OFF	= 0x7;
	const	int		MAGIC2_1_OFF	= 0xF;
	const	int		MAGIC2_2_OFF	= 0xE;
	const	int		MAGIC2_CHECK	= 0xD;
	const	int		REG_OFF		= 0x4;
	BYTE add_reg[] = { 0x83, 0xC0, 0 };

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	DWORD magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	DWORD block_size;
	DWORD magic2;
	if (decode_at[MAGIC2_CHECK]==0x35) {
		magic2 = *((DWORD*)(decode_at+MAGIC2_2_OFF));
		block_size = 0x16;
	}
	else {
		magic2= *((DWORD*)(decode_at+MAGIC2_1_OFF));
		block_size = 0x17;
	}

	DWORD add_value = (magic1<<1)^magic2;

	if ((add_value&0xFFFFFF00) != 0) {
		return E_FAIL;
	}

	BYTE	regInc = (decode_at[REG_OFF]&0x38)>>3;
	add_reg[1] |= regInc;
	add_reg[2] = (BYTE)add_value;

	injectNop(decode_at, block_size);
	memcpy(decode_at, add_reg, sizeof(add_reg));

	printf("  ADD  %s, 0x%X\n", getRegisterString(regInc), add_value);

	return S_OK;
}

/*
==========================================================================
                             SUB esp, 4+14
==========================================================================
00C8C008 83 EC 04                                sub     esp, 4          ; open temp dword to compute the real stack size
00C8C00B C7 04 24 F2 01 00 00                    mov     dword ptr [esp], 1F2h
00C8C012 81 34 24 E6 01 00 00                    xor     dword ptr [esp], 1E6h
00C8C019 2B 24 24                                sub     esp, [esp]      ; real stack size
*/
HRESULT srom_subesp_1(INPUT_HANDLING_FUNCTION* input)
{
	const	int		MAGIC1_OFF = 0x6;
	const	int		MAGIC2_OFF = 0xD;
	const	BYTE	sub_esp_instr[] = {0x81,0xEC};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;
	
	DWORD magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	DWORD magic2= *((DWORD*)(decode_at+MAGIC2_OFF));

	DWORD proper_stack_sub = (magic1^magic2);
	proper_stack_sub += 4;

	assert(proper_stack_sub != 0);

	injectNop(decode_at, 7*2+2*3);
	memcpy(decode_at, sub_esp_instr, sizeof(sub_esp_instr));
	*((DWORD*)(decode_at+sizeof(sub_esp_instr))) = proper_stack_sub;

	printf("  SUB   ESP, %X\n", proper_stack_sub);

	return S_OK;
}


/*
==========================================================================
                             ADD esp, 8
==========================================================================
00C8CC31 C7 04 24 63 03 00 00                    mov     dword ptr [esp], 363h
00C8CC38 81 34 24 6B 03 00 00                    xor     dword ptr [esp], 36Bh
00C8CC3F 03 24 24                                add     esp, [esp]

==========================================================================
                             ADD esp, 8 (short form)
==========================================================================
0080CCAC C7 04 24 79 00 00 00                 mov     dword ptr [esp], 79h
0080CCB3 83 34 24 71                          xor     dword ptr [esp], 71h
0080CCB7 03 24 24                             add     esp, [esp]
*/
HRESULT srom_addesp_1(INPUT_HANDLING_FUNCTION* input)
{
	const	int		SHORT_FORM_BYTE_CHECK = 0x7;
	const	int		MAGIC1_OFF = 0x3;
	const	int		MAGIC2_OFF = 0xA;
	const	BYTE	add_esp_instr[] = {0x81,0xC4};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	DWORD magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	DWORD magic2;

	if (decode_at[SHORT_FORM_BYTE_CHECK] == 0x81) {
		magic2= *((DWORD*)(decode_at+MAGIC2_OFF));
	}
	else if (decode_at[SHORT_FORM_BYTE_CHECK] == 0x83) {
		magic2 = sign_extend_8(decode_at[MAGIC2_OFF]);
	}
	else {
		return E_FAIL;
	}
	
	DWORD proper_stack_add = magic1^magic2;

	injectNop(decode_at, input->pat_size );
	memcpy(decode_at, add_esp_instr, sizeof(add_esp_instr));
	*((DWORD*)(decode_at+sizeof(add_esp_instr))) = proper_stack_add;

	printf("  ADD   ESP, %X\n", proper_stack_add);
	
	return S_OK;
}


/*
==========================================================================
                             Jcc ???  (v 1a)
==========================================================================
00C8C054 68 9B 32 00 00                          push    329Bh		; magic1
00C8C059 74 11                                   jz      short loc_C8C06C
; case false
00C8C05B 81 04 24 1F 8A C5 00                    add     dword ptr [esp], offset unk_C58A1F
00C8C062                         
00C8C062                         loc_C8C062:                             ; CODE XREF: 0000:00C8C069.j
00C8C062 81 04 24 C3 03 03 00                    add     dword ptr [esp], 303C3h
00C8C069 EB FA                                   jmp     short near ptr loc_C8C062+3
00C8C069                         ; ---------------------------------------------------------------------------
00C8C06B E7                                      db 0E7h ; �
00C8C06C                         ; ---------------------------------------------------------------------------
00C8C06C                         
;case true
00C8C06C                         loc_C8C06C:                             ; CODE XREF: 0000:00C8C059.j
00C8C06C 81 04 24 34 2E C5 00                    add     dword ptr [esp], offset unk_C52E34
00C8C073                         
00C8C073                         loc_C8C073:                             ; CODE XREF: 0000:00C8C07A.j
00C8C073 81 04 24 C3 5F 03 00                    add     dword ptr [esp], 35FC3h
00C8C07A EB FA                                   jmp     short near ptr loc_C8C073+3
*/
HRESULT srom_jcc_1a(INPUT_HANDLING_FUNCTION* input)
{
	const	int MAGIC1_OFF = 1;
	const	int J1_MAGIC1_OFF = 0xA;
	const	int J1_MAGIC2_OFF = 0x11;
	const	int J2_MAGIC1_OFF = 0x3;
	const	int J2_MAGIC2_OFF = 0xA;
	const	int JUMP_TYPE_OFF = 5;
	const	int MAX_TRUE_BLOCK_SEARCH = 0x110;
	const	BYTE jcc_true_branch_pat[] = {0x81,0x04,0x24};
	
	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	DWORD	magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	DWORD	caseFalseTarget = magic1 + *((DWORD*)(decode_at+J1_MAGIC1_OFF)) + *((DWORD*)(decode_at+J1_MAGIC2_OFF));
	BYTE	jump_type = decode_at[JUMP_TYPE_OFF] & 0x0F;

	DWORD jump_size;
	char *jump_prox;

	// FALSE branch handling
	injectNop(decode_at, 5);
	injectNop(decode_at+7, 0x10);

	jump_size = injectJump(decode_at+J1_MAGIC1_OFF-3, (DWORD)(decode_at+J1_MAGIC1_OFF-3+input->pat_match_delta), caseFalseTarget);

	jump_prox="near";
	if (jump_size==2) {
		jump_prox = "short";
	}

	// TRUE branch check
	DWORD i=0;
	while (i < MAX_TRUE_BLOCK_SEARCH && 0!=memcmp(decode_at+i, jcc_true_branch_pat, sizeof(jcc_true_branch_pat)) ) {
		i++;
	}

	if (i < MAX_TRUE_BLOCK_SEARCH && 0==memcmp(decode_at+i, jcc_true_branch_pat, sizeof(jcc_true_branch_pat)) ) {
		// we have something in the true branch
		DWORD	caseTrueTarget = magic1 + *((DWORD*)(decode_at+i+J2_MAGIC1_OFF)) + *((DWORD*)(decode_at+i+J2_MAGIC2_OFF));
		injectNop(decode_at+i, 0x10);
		jump_size = injectJump(decode_at+i, (DWORD)(decode_at+i+input->pat_match_delta), caseTrueTarget);

		jump_prox="near";
		if (jump_size==2) {
			jump_prox = "short";
		}
		printf(" IF true: JMP %-5s %08X   ELSE", jump_prox, caseTrueTarget);
	}
	else {
		printf( "*Unhandled True Case*      ELSE");
	}


	printf("   JMP %-5s %08X\n", jump_prox, caseFalseTarget);

	return S_OK;
}


/*
==========================================================================
                             Jcc ???  (v 1b)
==========================================================================
0083780D 6A 42                                   push    42h
0083780F 74 10                                   jz      short loc_837821
00837811 81 04 24 2C 60 82 00                    add     dword ptr [esp], 82602Ch
00837818                         
00837818                         loc_837818:                             ; CODE XREF: 0000:0083781F.j
00837818 81 04 24 C3 17 01 00                    add     dword ptr [esp], 117C3h
0083781F EB FA                                   jmp     short near ptr loc_837818+3
00837821                         ; ---------------------------------------------------------------------------
00837821                         
00837821                         loc_837821:                             ; CODE XREF: 0000:0083780F.j
00837821 81 04 24 BB FB 7F 00                    add     dword ptr [esp], 7FFBBBh
00837828                         
00837828                         loc_837828:                             ; CODE XREF: 0000:0083782F.j
00837828 81 04 24 C3 8E 03 00                    add     dword ptr [esp], 38EC3h
0083782F EB FA                                   jmp     short near ptr loc_837828+3

*/
HRESULT srom_jcc_1b(INPUT_HANDLING_FUNCTION* input)
{
	const	int MAGIC1_OFF = 1;
	const	int J1_MAGIC1_OFF = 0x7;
	const	int J1_MAGIC2_OFF = 0xE;
	const	int J2_MAGIC1_OFF = 0x3;
	const	int J2_MAGIC2_OFF = 0xA;
	const	int JUMP_TYPE_OFF = 3;
	const	int MAX_TRUE_BLOCK_SEARCH = 0x110;
	const	BYTE jcc_true_branch_pat[] = {0x81,0x04,0x24};
	
	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	DWORD	magic1= sign_extend_8(decode_at[MAGIC1_OFF]);
	DWORD	caseFalseTarget = magic1 + *((DWORD*)(decode_at+J1_MAGIC1_OFF)) + *((DWORD*)(decode_at+J1_MAGIC2_OFF));
	BYTE	jump_type = decode_at[JUMP_TYPE_OFF] & 0x0F;

	DWORD jump_size;
	char *jump_prox;

	// FALSE branch handling
	injectNop(decode_at, 2);
	injectNop(decode_at+4, 0x10);

	jump_size = injectJump(decode_at+J1_MAGIC1_OFF-3, (DWORD)(decode_at+J1_MAGIC1_OFF-3+input->pat_match_delta), caseFalseTarget);

	jump_prox="near";
	if (jump_size==2) {
		jump_prox = "short";
	}

	// TRUE branch check
	DWORD i=0;
	while (i < MAX_TRUE_BLOCK_SEARCH && 0!=memcmp(decode_at+i, jcc_true_branch_pat, sizeof(jcc_true_branch_pat)) ) {
		i++;
	}

	if (i < MAX_TRUE_BLOCK_SEARCH && 0==memcmp(decode_at+i, jcc_true_branch_pat, sizeof(jcc_true_branch_pat)) ) {
		// we have something in the true branch
		DWORD	caseTrueTarget = magic1 + *((DWORD*)(decode_at+i+J2_MAGIC1_OFF)) + *((DWORD*)(decode_at+i+J2_MAGIC2_OFF));
		injectNop(decode_at+i, 0x10);
		jump_size = injectJump(decode_at+i, (DWORD)(decode_at+i+input->pat_match_delta), caseTrueTarget);

		jump_prox="near";
		if (jump_size==2) {
			jump_prox = "short";
		}
		printf(" IF true: JMP %-5s %08X   ELSE", jump_prox, caseTrueTarget);
	}
	else {
		printf( "*Unhandled True Case*      ELSE");
	}


	printf("   JMP %-5s %08X\n", jump_prox, caseFalseTarget);

	return S_OK;
}


/*		SLICER HANDLER

NOTES:

 * The outcome of a slice is a constant on the stack.

 * A "slice" is a point where the code flow is randomly cut in half and 
   duplicated in two locations. Both paths are the same, but it is usually 
   hard to predict which code flow is taken from a dead-listing.

 * This function is considered 'risky' because it executes code in 
   securom.

 * 

==========================================================================
                              18h
==========================================================================
00C90930 9C                                      pushf
00C90931 83 EC 18                                sub     esp, 18h
00C90934 C7 44 24 14 6F A1 0C 6E                 mov     dword ptr [esp+14h], 6E0CA16Fh ; crc init
00C9093C C7 44 24 10 A4 01 00 00                 mov     dword ptr [esp+10h], 1A4h ; crc size
00C90944 89 7C 24 0C                             mov     [esp+0Ch], edi  ; push edi
00C90948 BF 00 09 C9 00                          mov     edi, offset unk_C90900 ; crc loc
00C9094D C1 4C 24 14 00                          ror     dword ptr [esp+14h], 0 ; ror factor
00C90952 89 5C 24 08                             mov     [esp+8], ebx    ; push ebx
00C90956                         
00C90956                         loc_C90956:                             ; CODE XREF: 0000:00C90965.j
00C90956 90                                      nop
00C90957 8B 1F                                   mov     ebx, [edi]
00C90959 01 5C 24 14                             add     [esp+14h], ebx
00C9095D 83 C7 04                                add     edi, 4
00C90960 66 FF 4C 24 10                          dec     word ptr [esp+10h]
00C90965 75 EF                                   jnz     short loc_C90956
00C90967 80 4C 24 14 01                          or      byte ptr [esp+14h], 1
00C9096C                         
00C9096C                         loc_C9096C:                             ; DATA XREF: 0000:00C909B5.o
00C9096C 8B 7C 24 18                             mov     edi, [esp+18h]  ; old pushf
00C90970 8B 5C 24 14                             mov     ebx, [esp+14h]
00C90974 89 7C 24 14                             mov     [esp+14h], edi  ; exchanges stack values
00C90978 8B 7C 24 0C                             mov     edi, [esp+0Ch]  ; pop edi
00C9097C 89 5C 24 18                             mov     [esp+18h], ebx
00C90980 8B 5C 24 08                             mov     ebx, [esp+8]    ; pop ebx
00C90984 8D 00                                   lea     eax, [eax]
00C90986 83 C4 14                                add     esp, 14h        ; un-balance the stack to open a spot for 

later on
00C90989 90                                      nop
00C9098A 9D                                      popf
00C9098B 7C 11                                   jl      short loc_C9099E ; *** slice here, totally random.
; -stack is unbalanced here-
; top of stack has a partial destination target.
; both branches will somehow sort things out.


==========================================================================
                              20h
==========================================================================
00C8CEB6 9C                                      pushf
00C8CEB7 83 EC 20                                sub     esp, 20h
00C8CEBA C7 44 24 1C 68 50 EF 09                 mov     dword ptr [esp+1Ch], 9EF5068h ; crc init
00C8CEC2 C7 44 24 18 53 00 00 00                 mov     dword ptr [esp+18h], 53h ;  crc size
00C8CECA 89 44 24 14                             mov     [esp+14h], eax
00C8CECE B8 84 CE C8 00                          mov     eax, 0C8CE84h   ; crc loc
00C8CED3 C1 4C 24 1C 10                          ror     dword ptr [esp+1Ch], 10h ;  ror factor
00C8CED8 89 54 24 10                             mov     [esp+10h], edx
00C8CEDC 90                                      nop
00C8CEDD                         
00C8CEDD                         loc_C8CEDD:                             ; CODE XREF: 0000:00C8CEEC.j
00C8CEDD 90                                      nop
00C8CEDE 8B 10                                   mov     edx, [eax]
00C8CEE0 01 54 24 1C                             add     [esp+1Ch], edx
00C8CEE4 83 C0 04                                add     eax, 4
00C8CEE7 66 FF 4C 24 18                          dec     word ptr [esp+18h]
00C8CEEC 75 EF                                   jnz     short loc_C8CEDD
00C8CEEE 87 F6                                   xchg    esi, esi
00C8CEF0 80 4C 24 1C 01                          or      byte ptr [esp+1Ch], 1
00C8CEF5 87 C9                                   xchg    ecx, ecx
00C8CEF7 8B 44 24 20                             mov     eax, [esp+20h]
00C8CEFB 8B 54 24 1C                             mov     edx, [esp+1Ch]
00C8CEFF 8D 1B                                   lea     ebx, [ebx]
00C8CF01 89 44 24 1C                             mov     [esp+1Ch], eax
00C8CF05 8B 44 24 14                             mov     eax, [esp+14h]
00C8CF09 89 54 24 20                             mov     [esp+20h], edx
00C8CF0D 8B 54 24 10                             mov     edx, [esp+10h]
00C8CF11 83 C4 1C                                add     esp, 1Ch
00C8CF14 9D                                      popf
00C8CF15 7A 10                                   jp      short loc_C8CF27
; -stack is unbalanced here-
; top of stack has a partial destination target.
; both branches will somehow sort things out.
*/
HRESULT srom_slice_1(INPUT_HANDLING_FUNCTION* input)
{
	const	int	STACK_SIZE_OFF	= 0x3;
	const	int CRC_LOC1_OFF	= 0x18;
	const	int MAX_STACK_MOD_END = 0x75;
	const	DWORD	PAGE_SIZE	= 0x1000;
	BYTE	stack_mod_end[] = {0x83,0xC4, 0};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	// search for the end of the block by getting a matching add esp, (NN-4)
	stack_mod_end[2] = decode_at[STACK_SIZE_OFF]-4;
	DWORD i=0;
	while (i < MAX_STACK_MOD_END && i+sizeof(stack_mod_end) < input->size_left && 0!=memcmp(decode_at+i, stack_mod_end, sizeof(stack_mod_end))) {
		i++;
	}

	if (i>=MAX_STACK_MOD_END || i+sizeof(stack_mod_end) >= input->size_left || 0!=memcmp(decode_at+i, stack_mod_end, sizeof(stack_mod_end))) {
		return E_FAIL;
	}

	i+=sizeof(stack_mod_end);

	// we also want the popfd
	while (i < MAX_STACK_MOD_END && i+sizeof(stack_mod_end) < input->size_left && decode_at[i]!=0x9D) {
		i++;
	}

	if (i>=MAX_STACK_MOD_END || i+sizeof(stack_mod_end) >= input->size_left ||decode_at[i]!=0x9D) {
		return E_FAIL;
	}
	i++;

	i+=eat_nop(decode_at+i);

	DWORD	stack_mod_size = i;

	// Allocate the memory & cc it for safety
	LPBYTE executePage = (LPBYTE) VirtualAlloc(NULL, PAGE_SIZE, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	memset(executePage, 0xCC, PAGE_SIZE);

	// copy the code
	memcpy(executePage, decode_at, stack_mod_size);

	// find the instruction setting a register to crc_loc
	DWORD crc_loc = *((DWORD*)(decode_at+CRC_LOC1_OFF+1));

	DWORD crc_loc_raw = PeImageRVAtoRawOffset(PeImageNtHeader(input->imageStart), input->imageStart, crc_loc - input->imageBase );
	DWORD crc_override_val = (DWORD) ((LPBYTE)input->virginImageStart + crc_loc_raw);

	// over-ride the crc_loc
	*((DWORD*)(executePage+CRC_LOC1_OFF+1)) = crc_override_val;

	DWORD stack_magic_value=0;
	__asm {
		pushad

		// stick a jump back to us at the end. (PUSH offset return_loc  /   RET)
		mov		eax, offset return_loc
		mov		edi, [executePage]
		add		edi, [stack_mod_size]
		mov		byte ptr [edi], 0x68
		mov		dword ptr [edi+1], eax
		mov		byte ptr [edi+5], 0xC3

		mov		eax, [executePage]
		push	eax
		
		ret
	return_loc:
		pop		eax
		mov		[stack_magic_value], eax
		popad
	}
	
	VirtualFree(executePage, 0, MEM_RELEASE);


	injectNop(decode_at, stack_mod_size);

	BYTE	slice_msg[] = {0xEB,7+4,0,'s','l','i','c','e',0,0,0,0,0};

	// leaving the constant as part of the slice msg; to help disassembly
	memcpy(slice_msg+sizeof(slice_msg)-sizeof(DWORD), &stack_magic_value, sizeof(DWORD));

	// copy the slice msg (but leave space for a push imm32
	memcpy(decode_at+stack_mod_size-5-sizeof(slice_msg), slice_msg, sizeof(slice_msg));

	decode_at[stack_mod_size-5]=0x68;
	*((DWORD*)(decode_at+stack_mod_size-4)) = stack_magic_value;

	printf("  Splicer <-> PUSH %X\n", stack_magic_value);


	return S_OK;
}


__declspec(naked) grab_const()
{
	__asm {
		pushad
	};

	if (memop.reg==REG_EAX) {
		__asm {
			popad
			mov	memop.constant, eax
			pushad
		}
	}
	else if (memop.reg==REG_EBX) {
		__asm {
			popad
			mov	memop.constant, ebx
			pushad
		}
	}
	else if (memop.reg==REG_ECX) {
		__asm {
			popad
			mov	memop.constant, ecx
			pushad
		}
	}
	else if (memop.reg==REG_EDX) {
		__asm {
			popad
			mov	memop.constant, edx
			pushad
		}
	}
	else if (memop.reg==REG_EDI) {
		__asm {
			popad
			mov	memop.constant, edi
			pushad
		}
	}
	else if (memop.reg==REG_ESI) {
		__asm {
			popad
			mov	memop.constant, esi
			pushad
		}
	}
	else if (memop.reg==REG_EBP) {
		__asm {
			popad
			mov	memop.constant, ebx
			pushad
		}
	}

	else {
		__asm {
			popad
		};
		assert(FALSE);
		printf("Major error\n");
		ExitProcess(0);
	}

	memcpy(memop.ret_to, memop.backup_bytes, sizeof(memop.backup_bytes));

	__asm {
		popad
		push	dword ptr [memop.ret_to]
		ret
	}
}



/*
	ADD REG, CONST

  
These blocks have to be simulated. 

1. Allocate a page of memory with VirtualAlloc
2. Fill the thing with 0xCC as a safe guard
3. Copy the code to be analyzed into it.
4. Override the crc_loc with the right in-mem value of the virgin file
5. Stick a jmp back to us (or trap the INT3)
6. Compare the registers; only one should have changed. Grab its new value. Substract the difference.


00C8CBD5 83 EC 20                                sub     esp, 20h
00C8CBD8 C7 44 24 1C 35 07 10 63                 mov     dword ptr [esp+1Ch], 63100735h ; magic1
00C8CBE0 C7 44 24 18 7C 00 02 00                 mov     dword ptr [esp+18h], 2007Ch ; magic2
00C8CBE8 89 54 24 14                             mov     [esp+14h], edx
00C8CBEC BA 8C CB C8 00                          mov     edx, 0C8CB8Ch   ; crc loc
00C8CBF1 89 44 24 10                             mov     [esp+10h], eax
00C8CBF5 89 54 24 1C                             mov     [esp+1Ch], edx
00C8CBF9 8B C0                                   mov     eax, eax
00C8CBFB 33 D2                                   xor     edx, edx
00C8CBFD 90                                      nop
00C8CBFE                         
00C8CBFE                         loc_C8CBFE:                             ; CODE XREF: 0000:00C8CC12.j
00C8CBFE 8B 44 24 1C                             mov     eax, [esp+1Ch]
00C8CC02 8B 00                                   mov     eax, [eax]
00C8CC04 33 D0                                   xor     edx, eax
00C8CC06 83 44 24 1C 04                          add     dword ptr [esp+1Ch], 4
00C8CC0B 66 FF 4C 24 18                          dec     word ptr [esp+18h]
00C8CC10 87 ED                                   xchg    ebp, ebp
00C8CC12 75 EA                                   jnz     short loc_C8CBFE
00C8CC14 8B 44 24 10                             mov     eax, [esp+10h]
00C8CC18 90                                      nop
00C8CC19 03 CA                                   add     ecx, edx
00C8CC1B 8B FF                                   mov     edi, edi
00C8CC1D 8B 54 24 14                             mov     edx, [esp+14h]
00C8CC21 83 C4 20                                add     esp, 20h
*/
HRESULT srom_addreg_const_1(INPUT_HANDLING_FUNCTION* input)
{
	#define	PAGE_SIZE	0x1000
	#define	STACK_SIZE	256*PAGE_SIZE	// 1 MEG
	const	int CRC_LOC1_OFF	= 0x17;
	const	int MAX_STACK_MOD_END = 0x85;
	BYTE	stack_mod_end[] = {0x83,0xC4, 0};
	BYTE	stack_mod_end_2[] = {0x83,0x44,0x24,0,0};
	BYTE	addreg_instr[] = {0x81,0xC0};
	BYTE	subreg_instr[] = {0x81,0xE8};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	/*
	if ((DWORD)(decode_at + input->pat_match_delta) == 0x80CEED) {
		printf("*here*");
	}*/

	// search for the end of the block by getting a matching add esp, NN
	stack_mod_end[2] = decode_at[2];
	DWORD i=0;
	while (i < MAX_STACK_MOD_END && i+sizeof(stack_mod_end) < input->size_left && 0!=memcmp(decode_at+i, stack_mod_end, sizeof(stack_mod_end))) {
		i++;
	}

	if (i>=MAX_STACK_MOD_END || i+sizeof(stack_mod_end) >= input->size_left || 0!=memcmp(decode_at+i, stack_mod_end, sizeof(stack_mod_end))) {

		// try to look for the 2nd form.

		stack_mod_end_2[4] = decode_at[2];
		stack_mod_end_2[3] = decode_at[2] - 0x10;

		i=0;
		while (i < MAX_STACK_MOD_END && i+sizeof(stack_mod_end_2) < input->size_left && 0!=memcmp(decode_at+i, stack_mod_end_2, sizeof(stack_mod_end_2))) {
			i++;
		}

		if (i >= MAX_STACK_MOD_END || i+sizeof(stack_mod_end_2) >= input->size_left || 0!=memcmp(decode_at+i, stack_mod_end_2, sizeof(stack_mod_end_2))) {
			return E_FAIL;
		}

		// 2nd form matches. Find the end.
		BYTE	stack_mod_end_2_end[] = {0x8B,0x64,0x24};
		DWORD j=0;
		while (j < MAX_STACK_MOD_END && j+sizeof(stack_mod_end_2_end) < input->size_left && 0!=memcmp(decode_at+i+j, stack_mod_end_2_end, sizeof(stack_mod_end_2_end))) {
			j++;
		}

		if (j >= MAX_STACK_MOD_END || j+sizeof(stack_mod_end_2_end) >= input->size_left || 0!=memcmp(decode_at+i+j, stack_mod_end_2_end, sizeof(stack_mod_end_2_end))) {
			return E_FAIL;;
		}

		i+=sizeof(stack_mod_end_2_end)+1+j;

		// we already have the end of the block, but we'll want to 'eat' as many useless instructions as possible
		j=eat_nop(decode_at+i);
		i+=j;
	}
	else {
		i+=sizeof(stack_mod_end);
		i+=eat_nop(decode_at+i);
	}


	// count the number of jumps (jccs) inside that block (should be 1)
	DWORD j=0;
	DWORD max_jcc_target=0;
	DWORD jcc_count=0;
	disasm_struct s = {4,4};   // prepare to disasm 32-bit code

	BYTE* visited = new BYTE[i];
	memset(visited, 0, sizeof(BYTE)*i);

	for (j=0; j < i;) {

		// disassemble opcode
		DWORD len = disasm(decode_at+j, &s);
		if (len == 0) { 
			printf("*error in disasm*");
			break; // cant disassemble?
		}
		visited[j]++;

		if (len==2 && decode_at[j] >= 0x70 && decode_at[j] <= 0x7F ) {
			jcc_count++;
			DWORD local_max_jcc_target = j+2+sign_extend_8(decode_at[j+1]);
			max_jcc_target = max(max_jcc_target, local_max_jcc_target);
			if (jcc_count==2) {
				j=j+2+sign_extend_8(decode_at[j+1]);
				j-=len;
			}
		}
		else if (len==2 && decode_at[j] == 0xEB && visited[j]==1) {
			j=j+2+sign_extend_8(decode_at[j+1]);
			j-=len;
		}
		j+=len;
	}
	SAFE_DELETE_ARRAY(visited);

	if ( max_jcc_target > i ) {
		//printf("Keep searching!! ");
		i=max_jcc_target;
		while (i < MAX_STACK_MOD_END && i+sizeof(stack_mod_end) < input->size_left && 0!=memcmp(decode_at+i, stack_mod_end, sizeof(stack_mod_end))) {
			i++;
		}
		if (i>=MAX_STACK_MOD_END || i+sizeof(stack_mod_end) >= input->size_left || 0!=memcmp(decode_at+i, stack_mod_end, sizeof(stack_mod_end))) {
			return E_FAIL;
		}
		i+=sizeof(stack_mod_end);
	}


	DWORD	stack_mod_size = i;


	// check if the block contains an memory addressing instruction
	// e.g.: mov [edx], ...
	//		 mov [ebp-####],..
	//
	jcc_count=0;
	visited = new BYTE[i];
	memset(visited, 0, sizeof(BYTE)*i);

	for (j=0; j < i;) {

		memset(&memop, 0, sizeof(MEMOP));
		int reg1=0,reg2=0,reg3=0;

		// disassemble opcode
		DWORD len = disasm(decode_at+j, &s);
		if (len == 0) { 
			printf("*error in disasm*");
			break; // cant disassemble?
		}
		visited[j]++;

		if (len==2 && decode_at[j] >= 0x70 && decode_at[j] <= 0x7F ) {
			jcc_count++;

			if (jcc_count==2) {
				j=j+2+sign_extend_8(decode_at[j+1]);
				j-=len;
			}
		}
		else if (len==2 && decode_at[j] == 0xEB && visited[j]==1) {
			j=j+2+sign_extend_8(decode_at[j+1]);
			j-=len;
		}
		else if (decode_at[j]==0xA3) {
			// MOV [DWORD], EAX
			memop.reg = REG_EAX;
			memop.valid = true;
			memop.location = decode_at + j;
			memop.len = len;
			memop.opcode = new BYTE[len];
			memcpy(memop.opcode, memop.location, len);
			goto LStopMemopScan;
		}
		else if (decode_at[j]==0x89) {
			switch ( (decode_at[j+1] & 0xC0)>>6) {
			case 0:
				// MOV [reg1+reg2*n], reg3
				reg1 = decode_at[j+1]&0x7;
				reg2 = (decode_at[j+1]&0x38)>>3;
				memop.reg = reg2;

				if (reg1==REG_ESP) {
					reg1 = decode_at[j+2]&0x7;
					reg2 = (decode_at[j+2]&0x38)>>3;
					reg3 = (decode_at[j+1]&0x38)>>3;

					if (reg1==REG_ESP || reg2==REG_ESP) {
						break;
					}
					memop.reg = reg3;
				}

				memop.valid = true;
				memop.location = decode_at + j;
				memop.len = len;
				memop.opcode = new BYTE[len];
				memcpy(memop.opcode, memop.location, len);
				goto LStopMemopScan;
				break;

			case 1:
				// MOV [reg1+imm8], reg2
				// MOV [reg1+reg2*n+imm8], reg3

				reg1 = decode_at[j+1]&0x7;
				reg2 = (decode_at[j+1]&0x38)>>3;
				memop.reg = reg2;

				if (reg1==REG_ESP) {
					reg1 = decode_at[j+2]&0x7;
					reg2 = (decode_at[j+2]&0x38)>>3;
					reg3 = (decode_at[j+1]&0x38)>>3;

					if (reg1==REG_ESP || reg2==REG_ESP) {
						break;
					}
					memop.reg = reg3;
				}
				memop.valid = true;
				memop.location = decode_at + j;
				memop.len = len;
				memop.opcode = new BYTE[len];
				memcpy(memop.opcode, memop.location, len);
				goto LStopMemopScan;
				break;

			case 2:
				// MOV [reg1+imm32], reg2
				// MOV [reg1+reg2+imm32], reg3
				reg1 = decode_at[j+1]&0x7;
				reg2 = (decode_at[j+1]&0x38)>>3;

				memop.reg = reg2;
				if (reg1==REG_ESP) {
					reg1 = decode_at[j+2]&0x7;
					reg2 = (decode_at[j+2]&0x38)>>3;
					reg3 = (decode_at[j+1]&0x38)>>3;

					if (reg1==REG_ESP || reg2==REG_ESP) {
						break;
					}
					memop.reg = reg3;
				}

				memop.valid = true;
				memop.location = decode_at + j;
				memop.len = len;
				memop.opcode = new BYTE[len];
				memcpy(memop.opcode, memop.location, len);
				goto LStopMemopScan;
				break;

			default:
				break;
			}
		}
		j+=len;
	}
LStopMemopScan:
	SAFE_DELETE_ARRAY(visited);


	if (memop.valid) {
		injectNop(memop.location, memop.len);

		BYTE	replacement_template[] = {0x50, 0xB8, 0, 0, 0, 0};
		replacement_template[0]|=memop.reg;
		replacement_template[1]|=memop.reg;
		//generate:
		// push memop.reg
		// MOV  memop.reg, const_to_be_found_somehow
		// memop.opcode
		// pop  memop.reg
		memop.replacement_len = sizeof(replacement_template)+ 1 + memop.len;
		memop.replacement = new BYTE[memop.replacement_len];
		memcpy(memop.replacement, replacement_template, sizeof(replacement_template));
		memcpy(memop.replacement + sizeof(replacement_template), memop.opcode, memop.len);
		memop.replacement[memop.replacement_len-1] = (0x58 | memop.reg);

		memop.ret_to = (LPBYTE)(memop.location - decode_at);

		memcpy(memop.backup_bytes, memop.location, sizeof(memop.backup_bytes));

		BYTE	hook_stub[] = { 0x68, 0,0,0,0, 0xC3};
		*((DWORD*)(hook_stub+1)) = (DWORD)(&grab_const);

		assert (sizeof(hook_stub) == sizeof(memop.backup_bytes));

		memcpy(memop.location, hook_stub, sizeof(hook_stub));

		SAFE_DELETE_ARRAY(memop.opcode);
	}



	// Allocate the memory & cc it for safety
	executePage = (LPBYTE) VirtualAlloc(NULL, PAGE_SIZE, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	memset(executePage, 0xCC, PAGE_SIZE);

	executePageStack = (LPBYTE) VirtualAlloc(NULL, STACK_SIZE, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	stack_size = decode_at[2];

	// copy the code
	memcpy(executePage, decode_at, stack_mod_size);

	// find the instruction setting a register to crc_loc
	DWORD crc_loc = *((DWORD*)(decode_at+CRC_LOC1_OFF+1));

	DWORD crc_loc_raw = PeImageRVAtoRawOffset(PeImageNtHeader(input->imageStart), input->imageStart, crc_loc - input->imageBase );
	DWORD crc_override_val = (DWORD) ((LPBYTE)input->virginImageStart + crc_loc_raw);

	// over-ride the crc_loc
	*((DWORD*)(executePage+CRC_LOC1_OFF+1)) = crc_override_val;


	if (memop.valid) {
		memop.ret_to = (memop.ret_to+(DWORD)executePage);
	}

	// execute it & save changes to GP registers
	DWORD	modEax, modEcx, modEdx, modEbx, modEbp, modEdi, modEsi, eFlags, old_eFlags, old_Ebp;
	__asm {
		pushad
		pushfd
		mov		eax, [esp]
		// clear CF, PF, AF, ZF, SF
		and		eax, 0xFFFFFF28
		mov		[esp], eax
		mov		[old_eFlags], 0
		popfd
		// stick a jump back to us at the end. (PUSH offset return_loc  /   RET)
		mov		eax, offset return_loc
		mov		edi, [executePage]
		add		edi, [stack_mod_size]
		mov		byte ptr [edi], 0x68
		mov		dword ptr [edi+1], eax
		mov		byte ptr [edi+5], 0xC3

		push	ebp
		// save what will eventually be "old-ebp"
		mov		eax, offset executePageStack
		mov		eax, [eax]
		add		eax, STACK_SIZE   // at the top of the stack
		sub		eax, 10
		mov		[old_Ebp], eax

		// backup old stack ptr, bring in new one.
		mov		eax, offset oldStack
		mov		[eax], esp
		
		// ***not-safe after this point. Don't use stack vars.***
		mov		ebp, offset executePageStack
		mov		ebp, [ebp]
		add		ebp, STACK_SIZE   // at the top of the stack
		sub		ebp, 10

		mov		esp, [executePageStack]
		add		esp, [stack_size]
		add		esp, 0x1000	// just to be safe

		mov		eax, [executePage]		
		push	eax
		xor		eax, eax
		xor		ecx, ecx
		xor		edx, edx
		xor		ebx, ebx
		xor		edi, edi
		xor		esi, esi

		mov		[entryStack], esp
		add		[entryStack], 4			// inbalanced because of the RET.
		ret

	return_loc:

		// in case something is left on the top of the stack.
		mov		[exitStack], esp

		// re-capture stack
		mov		esp, offset oldStack
		mov		esp, [esp]

		xchg	ebp, [esp]
		mov		[modEax], eax
		pushfd
		pop		eax
		// only save CF, AF, ZF, SF (warn: skipping PF)
		and		eax, 0xD1
		mov		[eFlags], eax
		pop		eax
		mov		[modEbp], eax
		mov		[modEcx], ecx
		mov		[modEdx], edx
		mov		[modEbx], ebx
		mov		[modEdi], edi
		mov		[modEsi], esi
		popad
	}
	
	VirtualFree(executePage, 0, MEM_RELEASE);
	VirtualFree(executePageStack, 0, MEM_RELEASE);

	// find out what was changed.
	DWORD	modified_reg=-1;
	DWORD	modified_reg_value=-1;
	/*if (eFlags!=old_eFlags) {
		printf("Eflags (TBD)\n");
		injectNop(decode_at, stack_mod_size);
		return S_OK;
	}
	else*/ if (modEax) {
		modified_reg_value=modEax;
		modified_reg = REG_EAX;
	}
	else if (modEcx) {
		modified_reg_value=modEcx;
		modified_reg = REG_ECX;
	}
	else if (modEdx) {
		modified_reg_value=modEdx;
		modified_reg = REG_EDX;
	}
	else if (modEbx) {
		modified_reg_value=modEbx;
		modified_reg = REG_EBX;
	}
	else if (modEsi) {
		modified_reg_value=modEsi;
		modified_reg = REG_ESI;
	}
	else if (modEdi) {
		modified_reg_value=modEdi;
		modified_reg = REG_EDI;
	}
	else if (modEbp != old_Ebp) {
		modified_reg_value=modEbp-old_Ebp;
		modified_reg = REG_EBP;
	}
	else if (exitStack != entryStack) {

		int		offset_imm32=0;
		BYTE	push_const_instr[5] = {0x68,0,0,0,0};

		// Get the top stack value, this is what was left over to us.
		//TBDTBD: use exception handler here.
		__try {
			//offset_imm32 = ;
			injectNop(decode_at, stack_mod_size);
			memcpy(push_const_instr+1, &offset_imm32, sizeof(offset_imm32));
			memcpy(decode_at+stack_mod_size-sizeof(push_const_instr), push_const_instr, sizeof(push_const_instr));

			printf("PUSH 0x%X\n", offset_imm32);
		}
		__except(EXCEPTION_EXECUTE_HANDLER) {
			injectNop(decode_at, stack_mod_size);

			printf("*Failed* to handle PUSH\n");
		}

		return S_OK;
	}
	else {
		if (memop.valid) {
			printf("Special case using '%s'=0x%X\n", getRegisterString(memop.reg), memop.constant);
			*((DWORD*)(memop.replacement+2)) = memop.constant;
			injectNop(decode_at, stack_mod_size);
			memcpy(decode_at, memop.replacement, memop.replacement_len);
			SAFE_DELETE_ARRAY(memop.replacement);
			return S_OK;
		}
		else {

			printf("(No registers modified. pure checksum).\n");
			injectNop(decode_at, stack_mod_size);
			return S_OK;
		}
	}

	injectNop(decode_at, stack_mod_size);
	
	// build a new ADD/SUB reg, CONST	instruction
	if (modified_reg_value&0x80000000) {
		subreg_instr[1]|=modified_reg;
		memcpy(decode_at+stack_mod_size-6, subreg_instr, sizeof(subreg_instr));
		*((DWORD*)(decode_at+stack_mod_size-6+sizeof(subreg_instr))) = 0-modified_reg_value;

		printf("  SUB  %s, %X\n", getRegisterString(modified_reg), 0-modified_reg_value);
	}
	else {
		addreg_instr[1]|=modified_reg;
		memcpy(decode_at+stack_mod_size-6, addreg_instr, sizeof(addreg_instr));
		*((DWORD*)(decode_at+stack_mod_size-6+sizeof(addreg_instr))) = modified_reg_value;

		printf("  ADD  %s, %X\n", getRegisterString(modified_reg), modified_reg_value);
	}

	return S_OK;
	#undef	PAGE_SIZE
}




/*
==========================================================================
                             MOV EAX, 180C
=========================================================================
009F8AEE 68 93 00 00 00                       push    93h
009F8AF3 81 34 24 9F 18 00 00                 xor     dword ptr [esp], 189Fh
009F8AFA 58                                   pop     eax

==========================================================================
                             MOV EAX, 1004
=========================================================================
00807097 68 08 16 00 00                       push    1608h
0080709C 81 34 24 0C 06 00 00                 xor     dword ptr [esp], 60Ch
008070A3 58                                   pop     eax

==========================================================================
                             MOV EAX, 100h (short form)
=========================================================================
.text:00F83DFD 6A 00                                push    0
.text:00F83DFF 81 34 24 00 01 00 00                 xor     dword ptr [esp], 100h
.text:00F83E06 59                                   pop     ecx

==========================================================================
                             MOV EAX, 5 (short-short form)
=========================================================================
0099F86A 6A 47                                push    47h
0099F86C 83 34 24 42                          xor     dword ptr [esp], 42h
0099F870 58                                   pop     eax
*/
HRESULT srom_mov_reg_imm32(INPUT_HANDLING_FUNCTION* input)
{
	int		MAGIC1_OFF = 0x1;
	int		MAGIC2_OFF = 0x8;
	int		REG_OFF	   = 0xC;
	BYTE	proper_mov[] = {0xB8, 0,0,0,0};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;
	DWORD	magic1, magic2;

	if (*decode_at == 0x68)  {
		// normal
		magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
		magic2= *((DWORD*)(decode_at+MAGIC2_OFF));
	}
	else if (decode_at[0] == 0x6A) {
		if (decode_at[2] == 0x81) {
			// short
			MAGIC1_OFF = 0x1;
			MAGIC2_OFF = 0x5;
			REG_OFF	   = 0x9;

			magic1= sign_extend_8(decode_at[MAGIC1_OFF]);
			magic2= *((DWORD*)(decode_at+MAGIC2_OFF));
		}
		else if (decode_at[2] == 0x83) {
			// short-short
			MAGIC1_OFF = 0x1;
			MAGIC2_OFF = 0x5;
			REG_OFF	   = 0x6;

			magic1= sign_extend_8(decode_at[MAGIC1_OFF]);
			magic2= sign_extend_8(decode_at[MAGIC2_OFF]);
		}
		else {
			return E_FAIL;
		}
	}
	else {
		return E_FAIL;
	}



	int	reg = decode_at[REG_OFF]&0x7;

	DWORD proper_imm32 = (magic1^magic2);
	proper_mov[0]|=reg;
	*((DWORD*)(proper_mov+1)) = proper_imm32;

	injectNop(decode_at, input->pat_size);
	memcpy(decode_at, proper_mov, sizeof(proper_mov));

	printf("  MOV  %s, 0x%X\n", getRegisterString(reg), proper_imm32);

	return S_OK;
}



/*
==========================================================================
                             MOV EAX, [0D202F8]
=========================================================================
00C8D962 B8 D1 5E F5 FF                          mov     eax, 0FFF55ED1h
00C8D967 8B 80 27 A4 DC 00                       mov     eax, [eax+0DCA427h]


==========================================================================
                             MOV ECX, [0D20300]
=========================================================================
00C90DB4 B9 A1 57 F8 FF                          mov     ecx, 0FFF857A1h
00C90DB9 8B 89 5F AB D9 00                       mov     ecx, [ecx+0D9AB5Fh]

==========================================================================
                             LEA ECX, [ebp+0FCh]
=========================================================================
011D5CB2 B9 71 24 FC FF                    mov   ecx, 0FFFC2471h
011D5CB7 8D 8C 29 8B DB 03 00              lea   ecx, [ecx+ebp+3DB8Bh]

*/
HRESULT srom_movlea_reg_dword(INPUT_HANDLING_FUNCTION* input)
{
	const	int		MAGIC1_OFF = 0x1;
	const	int		MAGIC2_OFF = 0x7;
	const	int		I1_REG1		= 0;
	const	int		I1_REG1_MASK= 0x7;
	const	int		I2_REG1		= 6;
	const	int		I2_REG1_MASK= 0x38;
	const	int		I2_REG2		= 6;
	const	int		I2_REG2_MASK= 0x7;
	const	int		INSTR_TYPE=0x5;



	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;
	
	DWORD magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	DWORD magic2= *((DWORD*)(decode_at+MAGIC2_OFF));

	DWORD i1_reg1 = decode_at[I1_REG1] & I1_REG1_MASK;
	DWORD i2_reg1 = (decode_at[I2_REG1] & I2_REG1_MASK)>>3;
	DWORD i2_reg2 = decode_at[I2_REG2] & I2_REG2_MASK;

	EVAL_MOV_LEA	eml;
	eml.reg_num=i1_reg1;
	eml.reg_val=magic1;
	if (1==reduce_mov_lea_sib_dwordptr_instructions(decode_at+5, &eml)) {
		// RHS has a "[reg*scale+dword]"
		BYTE	proper_dword_read[] = {0, 0x04};
		// the first byte of the proper instruction is the same as the first byte of the 2nd instruction
		proper_dword_read[0] = decode_at[INSTR_TYPE];
		proper_dword_read[1] |= (i1_reg1<<3);

		disasm_struct s = {4,4};
		DWORD len1=disasm(decode_at, &s);
		DWORD len2=disasm(decode_at+len1, &s);
		assert(len1!=0 && len2!=0);

		if (decode_at[INSTR_TYPE]==0x8B) { printf("  MOV  "); }
		else { printf("  LEA  "); }
		printf("%s, dword ptr [%s", getRegisterString(i1_reg1), getRegisterString(eml.index_reg));
		if (eml.scale!=0) {
			printf("*%d", 1<<eml.scale );
		}
		printf(" + 0x%X]", eml.imm);

		injectNop(decode_at, len1+len2);
		if (eml.index_reg == REG_EBP && eml.scale==0) {
			// Special case: we are dealing with just a stack access
			// we do this for IDA, so it doesn't choke on
			// 8D 0C 2D ?? ?? ?? ??  form of access to the stack.
			// Instead, we use the form:
			// 8D 85 ?? ?? ?? ??
			printf("  *EBP/Stack Access*");
			proper_dword_read[1] = 0x85; 
			proper_dword_read[1]|= (i1_reg1<<3);
			memcpy(decode_at, proper_dword_read, sizeof(proper_dword_read));
			memcpy(decode_at+sizeof(proper_dword_read), &eml.imm, sizeof(eml.imm));
		}
		else {
			memcpy(decode_at, proper_dword_read, sizeof(proper_dword_read));
			memcpy(decode_at+sizeof(proper_dword_read), eml.block, sizeof(eml.block));
		}
		printf("\n");
	}
	else {
		// RHS is a dword ptr directly
		BYTE	proper_dword_read[] = {0x0, 0x05};

		// sanity check, all registers are the same
		if (!(i2_reg1 == i2_reg2 && i1_reg1 == i2_reg1) ) {
			return E_FAIL;
		}

		DWORD	real_dword_read = magic1+magic2;
		// the first byte of the proper instruction is the same as the first byte of the 2nd instruction
		proper_dword_read[0] = decode_at[INSTR_TYPE];
		proper_dword_read[1] |= (i1_reg1<<3);

		disasm_struct s = {4,4};
		DWORD len1=disasm(decode_at, &s);
		DWORD len2=disasm(decode_at+len1, &s);
		assert(len1!=0 && len2!=0);

		if (decode_at[INSTR_TYPE]==0x8B) { printf("  MOV  "); }
		else { printf("  LEA  "); }
		printf("%s, dword ptr [%X]\n", getRegisterString(i1_reg1), real_dword_read);

		injectNop(decode_at, len1+len2);

		memcpy(decode_at, proper_dword_read, sizeof(proper_dword_read));
		*((DWORD*)(decode_at+sizeof(proper_dword_read))) = real_dword_read;
	}
	return S_OK;
}



/*
==========================================================================
                             dword ptr [esp+0]
==========================================================================
00C90A16 B8 99 1D F3 FF                          mov     eax, 0FFF31D99h
00C90A1B 8B 84 04 67 E2 0C 00                    mov     eax, [esp+eax+0CE267h] ; esp+0

==========================================================================
                             dword ptr [ebp+FFFFFFF4]
==========================================================================
00C8C027 B8 B5 E5 FE FF                          mov     eax, 0FFFEE5B5h
00C8C02C 8B 84 28 3F 1A 01 00                    mov     eax, [eax+ebp+11A3Fh]
*/
HRESULT srom_stack_read_1(INPUT_HANDLING_FUNCTION* input)
{

	BYTE	proper_stack_read[] = {0x8b, 0x80, 0};
	const	int		MAGIC1_OFF = 0x1;
	const	int		MAGIC2_OFF = 0x8;
	const	int		I1_REG1		= 0;
	const	int		I1_REG1_MASK= 0x7;
	const	int		I2_REG1		= 6;
	const	int		I2_REG1_MASK= 0x38;
	const	int		I2_REG2		= 7;
	const	int		I2_REG2_MASK= 0x38;
	const	int		I2_REG3		= 7;
	const	int		I2_REG3_MASK= 0x7;

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	DWORD magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	DWORD magic2= *((DWORD*)(decode_at+MAGIC2_OFF));

	DWORD i1_reg1 = decode_at[I1_REG1] & I1_REG1_MASK;
	DWORD i2_reg1 = (decode_at[I2_REG1] & I2_REG1_MASK)>>3;
	DWORD i2_reg2 = (decode_at[I2_REG2] & I2_REG2_MASK)>>3;
	DWORD i2_reg3 = decode_at[I2_REG3] & I2_REG3_MASK;

	if (i1_reg1 != i2_reg1) {
		return E_FAIL;
	}

	DWORD stack_offset = magic1+magic2;

	if (i2_reg2 == REG_ESP || i2_reg3 == REG_ESP) {
		proper_stack_read[1] = 0x84;
		proper_stack_read[1] |= (i2_reg1<<3);
		proper_stack_read[2] = 0x24;

		memcpy(decode_at, proper_stack_read, sizeof(proper_stack_read));
		*((DWORD*)(decode_at+3)) = stack_offset;
		injectNop(decode_at+7, 5);
		printf("  MOV %s, [ESP+0x%X]\n", getRegisterString(i2_reg1), stack_offset);
	}
	else {

		// insert new reg1
		proper_stack_read[1] |= (i2_reg1<<3);
		// choose which one will be new reg2.
		if (i2_reg2!=i2_reg1) {
			proper_stack_read[1] |= i2_reg2;
			printf("  MOV %s, [%s+0x%X]\n", getRegisterString(i2_reg1), getRegisterString(i2_reg2), stack_offset);
		}
		else {
			proper_stack_read[1] |= i2_reg3;
			printf("  MOV %s, [%s+0x%X]\n", getRegisterString(i2_reg1), getRegisterString(i2_reg3), stack_offset);
		}
		memcpy(decode_at, proper_stack_read, 2); // not the full size
		*((DWORD*)(decode_at+2)) = stack_offset;
		injectNop(decode_at+6, 6);
	}

	return S_OK;
}

/*
00C90FAC FF 34 24                                push    dword ptr [esp]
00C90FAF                         
00C90FAF                         loc_C90FAF:                             ; CODE XREF: 0000:00C90FB7.j
00C90FAF C7 44 24 04 C2 04 00 13                 mov     dword ptr [esp+4], 130004C2h
00C90FB7 EB FA                                   jmp     short near ptr loc_C90FAF+4
*/
HRESULT srom_ret(INPUT_HANDLING_FUNCTION* input)
{
	const	BYTE	proper_ret[] = {0xC3};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	injectNop(decode_at, 0xd);

	memcpy(decode_at, proper_ret, sizeof(proper_ret));

	printf("Ret fixed\n");
	return S_OK;
}


/*
00C8CF39 8B E5                                      mov     esp, ebp
00C8CF3B 8B 2C 24                                   mov     ebp, [esp]
00C8CF3E 83 C4 04                                   add     esp, 4
00C8CF41 FF 34 24                                   push    dword ptr [esp]
00C8CF44                            
00C8CF44                            loc_C8CF44:                             ; CODE XREF: 0000:00C8CF4C.j
00C8CF44 C7 44 24 04 C2 04 00 7C                    mov     dword ptr [esp+4], 7C0004C2h
00C8CF4C EB FA                                      jmp     short near ptr loc_C8CF44+4

*/
HRESULT	srom_epilog_1(INPUT_HANDLING_FUNCTION* input)
{
	const	BYTE	proper_epilog[] = {0x8b, 0xe5, 0x5d, 0xC3};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	injectNop(decode_at, 0x15);

	memcpy(decode_at, proper_epilog, sizeof(proper_epilog));

	printf("Epilog fixed\n");
	return S_OK;
}


/*
00C8C000 83 EC 04                                sub     esp, 4
00C8C003 89 2C 24                                mov     [esp], ebp      ; push ebp
00C8C006 8B EC                                   mov     ebp, esp
*/
HRESULT	srom_prolog_1(INPUT_HANDLING_FUNCTION* input)
{
	const	BYTE	proper_prolog[] = {0x55, 0x8b, 0xec};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	injectNop(decode_at, 0x8);

	// insert a proper function start
	memcpy(decode_at, proper_prolog, sizeof(proper_prolog));

	printf("Prolog fixed\n");
	return S_OK;
}


/*
00C90BD4 E8 0A 00 00 00                          call    loc_C90BE3			; small_call_loc
00C90BD4                         ; ---------------------------------------------------------------------------
00C90BD9 13 84 AA 2A                             dd 2AAA8413h
00C90BDD 90 C8 00 81                             dd 8100C890h				; magic3 is somewhere in here.
00C90BE1 31 E5                                   dw 0E531h
00C90BE3                         ; ---------------------------------------------------------------------------
00C90BE3                         
00C90BE3                         loc_C90BE3:                             ; CODE XREF: 0000:00C90BD4.p
00C90BE3 81 04 24 39 00 00 00                    add     dword ptr [esp], 39h	; magic1 (this will also serve as ret point, from call)
00C90BEA FF 34 24                                push    dword ptr [esp]
00C90BED 81 2C 24 36 00 00 00                    sub     dword ptr [esp], 36h	; magic2
00C90BF4 FF 34 24                                push    dword ptr [esp]
00C90BF7 87 2C 24                                xchg    ebp, [esp]
00C90BFA 8B 6D 00                                mov     ebp, [ebp+0]
00C90BFD 81 C5 D6 2F 00 00                       add     ebp, 2FD6h		; magic4
00C90C03 87 2C 24                                xchg    ebp, [esp]
00C90C06                         
00C90C06                         loc_C90C06:                             ; CODE XREF: 0000:00C90C0E.j
00C90C06 C7 44 24 04 C2 04 00 15                 mov     dword ptr [esp+4], 150004C2h
00C90C0E EB FA                                   jmp     short near ptr loc_C90C06+4
*/
HRESULT srom_call_1(INPUT_HANDLING_FUNCTION* input)
{
	const	int		MAGIC1_OFF = 0x3;
	const	int		MAGIC2_OFF = 0xD;
	const	int		MAGIC3_MAX_OFF = 25;
	const	BYTE	MAGIC3_PAT[] = {0xE8};
	const	int		MAGIC4_MAX_OFF = 0xC0;

	const	BYTE	safe_check_before_erase[] = {0xC7,0x44,0x24,0x04,0xC2,0x04};

	// The pattern scan brings us at the "add     dword ptr [esp]" line.
	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;
	
	/*if ((DWORD)(decode_at + input->pat_match_delta) == 0x80D0D1) {
		printf("*here*");
	}*/

	DWORD	magic1, magic2, magic3, magic4;

	magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	magic2= *((DWORD*)(decode_at+MAGIC2_OFF));


	// find the initiating call.
	DWORD	i=0;
	while (i < MAGIC3_MAX_OFF ) {
		if (!IsBadReadPtr(decode_at - i, 5) && memcmp(decode_at - i, MAGIC3_PAT, sizeof(MAGIC3_PAT))==0) {
			// check if the call that we found leads back to decode_at (start of pattern)
			if (   decode_at == (decode_at - i + 5 + *((DWORD*)(decode_at - i + 1)))  ) {
				break;
			}
		}

		i++;
	}

	if (i >= MAGIC3_MAX_OFF || 0!=memcmp(decode_at - i, MAGIC3_PAT, sizeof(MAGIC3_PAT))) {
		return E_FAIL;
	}

	LPBYTE	small_call_loc = decode_at - i;


	LPBYTE	small_call_ret	 = small_call_loc + 5;
	magic3 = *((DWORD*)(small_call_ret + magic1 - magic2));


	i=MAGIC2_OFF;
	while ( i < MAGIC4_MAX_OFF && i < input->size_left && !(decode_at[i]==0x87 && decode_at[i+2]==0x24) ) {
		i++;
	}

	if (i >= MAGIC4_MAX_OFF || i >= input->size_left || !(decode_at[i]==0x87 && decode_at[i+2]==0x24) ) {
		return E_FAIL;
	}
	
	i++;
	while ( i < MAGIC4_MAX_OFF && i < input->size_left && !(decode_at[i]==0x87 && decode_at[i+2]==0x24) ) {
		i++;
	}

	if (i >= MAGIC4_MAX_OFF || i >= input->size_left || !(decode_at[i]==0x87 && decode_at[i+2]==0x24) ) {
		return E_FAIL;
	}


	// TBDTBD: a little bit quick-n-dirty.
	if (decode_at[i-6]==0x81) {
		magic4 = *((DWORD*)(decode_at+i-4));
	}
	else if (decode_at[i-8]==0x81) {
		magic4 = *((DWORD*)(decode_at+i-6));
	}
	else if (decode_at[i-5]==0x5) {
		magic4 = *((DWORD*)(decode_at+i-4));
	}
	else if (decode_at[i-3]==0x83 && decode_at[i-2]>=0xC0 && decode_at[i-2]<=0xC7) {
		magic4 = sign_extend_8(decode_at[i-1]);
	}
	else {
		magic4 = 0;
		printf("*Warning magic4=0* ");
		//return E_FAIL;
	}

	injectE8Call(small_call_loc, (DWORD)(small_call_loc+input->pat_match_delta), magic3+magic4);

	injectNop(small_call_ret, magic1);

	printf("Target: %08X.\n", magic3+magic4);

	return S_OK;
}



/*
00C8C07F 83 EC 04                                sub     esp, 4
00C8C082 C7 04 24 F3 DD B8 00                    mov     dword ptr [esp], 0B8DDF3h
00C8C089                         
00C8C089                         loc_C8C089:                             ; CODE XREF: 0000:00C8C090.j
00C8C089 81 04 24 C3 F0 0F 00                    add     dword ptr [esp], 0FF0C3h
00C8C090 EB FA                                   jmp     short near ptr loc_C8C089+3
*/
HRESULT srom_jmp_1(INPUT_HANDLING_FUNCTION* input)
{
	const	int	MAGIC1_OFF	= 6;
	const	int MAGIC2_OFF	= 0xd;

	DWORD	magic1,magic2;
	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	if (input->size_left < 0x13) {
		return E_FAIL;
	}


	/*get magic values*/
	magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	magic2= *((DWORD*)(decode_at+MAGIC2_OFF));

	injectNop(decode_at, 0x13);

	DWORD jump_size = injectJump(decode_at, (DWORD)(decode_at+input->pat_match_delta), magic1+magic2);

	printf("Target: %08X. (jmpsize=%d)\n", magic1+magic2, jump_size);

	return S_OK;
}


/*
==========================================================================
                             Anti TRAP FLAG tracing
==========================================================================
.init:011D07C0 50                                push  eax
.init:011D07C1 16                                push  ss
.init:011D07C2 17                                pop   ss
.init:011D07C3 9C                                pushf
.init:011D07C4 8B 04 24                          mov   eax, [esp]
.init:011D07C7 F6 C4 01                          test  ah, 1			; TRAP FLAG TEST
.init:011D07CA 74 05                             jz    short loc_11D07D1
.init:011D07CC B9 BE 07 00 00                    mov   ecx, 7BEh
.init:011D07D1
.init:011D07D1                         loc_11D07D1:                            ; CODE XREF: 

.init:011D07CA.j
.init:011D07D1 33 C0                             xor   eax, eax
.init:011D07D3 74 01                             jz    short loc_11D07D6
.init:011D07D3                         ; 

---------------------------------------------------------------------------
.init:011D07D5 E8                                db 0E8h ; F
.init:011D07D6                         ; 

---------------------------------------------------------------------------
.init:011D07D6
.init:011D07D6                         loc_11D07D6:                            ; CODE XREF: 

.init:011D07D3.j
.init:011D07D6 9D                                popf
.init:011D07D7 58                                pop   eax
*/
HRESULT srom_anti_trace_1(INPUT_HANDLING_FUNCTION* input)
{
	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	// just NOP him out.
	injectNop(decode_at, input->pat_size);

/*	// stick a jump to make the disasm smaller.
	injectJump(decode_at, 
		(DWORD) (decode_at + input->pat_match_delta),
		(DWORD) (decode_at + input->pat_match_delta + input->pat_size) 
		);
*/
	printf(" Fixed\n");

	return S_OK;
}


/*
==========================================================================
                             PUSH OFFSET 127324Ch
==========================================================================
.text:00EDC68E 68 54 38 27 01                          push    offset unk_1273854
.text:00EDC693 81 2C 24 08 06 00 00                    sub     dword ptr [esp], 608h

==========================================================================
                             PUSH OFFSET 127324Ch
==========================================================================
.text:00EDC6E8 68 84 2F 27 01                          push    offset unk_1272F84
.text:00EDC6ED 81 04 24 C8 02 00 00                    add     dword ptr [esp], 2C8h

==========================================================================
                             PUSH OFFSET 1303704h (short form)
==========================================================================
.text:01174601 6A 50                          push    50h
.text:01174603 81 04 24 B4 36+                add     dword ptr [esp], 13036B4h
*/
HRESULT srom_push_offset_1(INPUT_HANDLING_FUNCTION* input)
{
	const	int	MAGIC1_OFF	= 1;
	int		MAGIC2_OFF		= 0x8;
	int		MODIFIER_OFF	= 0x6;

	DWORD	magic1,magic2,offset_imm;
	BYTE	modifier;
	BYTE	proper_push[5] = {0x68,0,0,0,0};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	/*get magic values*/
	if (decode_at[0] == 0x68) {
		// long form
		magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	}
	else if (decode_at[0] == 0x6A) {
		// short form
		MAGIC2_OFF = 0x5;
		MODIFIER_OFF = 0x3;
		magic1= sign_extend_8(decode_at[MAGIC1_OFF]);
	}
	else {
		return E_FAIL;
	}

	magic2= *((DWORD*)(decode_at+MAGIC2_OFF));
	modifier = decode_at[MODIFIER_OFF];

	switch((modifier>>3)&0x7) {
	case 0:
		// ADD
		offset_imm = magic1 + magic2;
		printf(" (via ADD) ");
		break;
	case 1:
		// OR
		offset_imm = magic1 | magic2;
		printf(" (via OR) ");
		break;
	case 4:
		// AND
		offset_imm = magic1 & magic2;
		printf(" (via AND) ");
		break;
	case 5:
		// SUB
		offset_imm = magic1 - magic2;
		printf(" (via SUB) ");
		break;
	case 6:
		// XOR
		offset_imm = magic1 ^ magic2;
		printf(" (via XOR) ");
		break;

	case 2:	// ADC
	case 3:	// SBB
	case 7:	// CMP
		return E_FAIL;
		break;
	}

	injectNop(decode_at, input->pat_size);
	memcpy(proper_push+1, &offset_imm, sizeof(offset_imm));
	memcpy(decode_at, proper_push, sizeof(proper_push));

	printf("PUSH OFFSET 0x%08X\n", offset_imm);

	return S_OK;
}


/*
==========================================================================
                             PUSH OFFSET 1307538
==========================================================================
.text:00CB896C 83 EC 04                                sub     esp, 4
.text:00CB896F 89 3C 24                                mov     [esp], edi
.text:00CB8972 BF 28 98 30 01                          mov     edi, 1309828	; magic1
.text:00CB8977 83 EC 04                                sub     esp, 4
.text:00CB897A 89 3C 24                                mov     [esp], edi
.text:00CB897D BF 3D 36 00 00                          mov     edi, 363Dh	; magic2
.text:00CB8982 81 F7 CD 14 00 00                       xor     edi, 14CDh	; magic3
.text:00CB8988 29 3C 24                                sub     [esp], edi
.text:00CB898B 5F                                      pop     edi
.text:00CB898C 87 3C 24                                xchg    edi, [esp]

==========================================================================
                             PUSH OFFSET 148A420 (short form)
==========================================================================
.text:01174AB1 83 EC 04                             sub     esp, 4
.text:01174AB4 89 3C 24                             mov     [esp], edi
.text:01174AB7 BF 48 C3 48 01                       mov     edi, 148C348
.text:01174ABC 83 EC 04                             sub     esp, 4
.text:01174ABF 89 3C 24                             mov     [esp], edi
.text:01174AC2 BF 12 1F 00 00                       mov     edi, 1F12h
.text:01174AC7 83 F7 3A                             xor     edi, 3Ah
.text:01174ACA 29 3C 24                             sub     [esp], edi
.text:01174ACD 5F                                   pop     edi
.text:01174ACE 87 3C 24                             xchg    edi, [esp]

*/
HRESULT srom_push_offset_2(INPUT_HANDLING_FUNCTION* input)
{
	const	int	MAGIC1_OFF	= 0x7;
	const	int MAGIC2_OFF	= 0x12;
	const	int	MAGIC3_OFF	= 0x18;
	const	int TYPE_OFF	= 0x16;

	DWORD	magic1,magic2,magic3,offset_imm;
	BYTE	proper_push[5] = {0x68,0,0,0,0};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	/*get magic values*/
	magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	magic2= *((DWORD*)(decode_at+MAGIC2_OFF));

	if (decode_at[TYPE_OFF] == 0x81) {
		// normal
		magic3= *((DWORD*)(decode_at+MAGIC3_OFF));
	}
	else if (decode_at[TYPE_OFF] == 0x83) {
		// short
		magic3 = sign_extend_8(decode_at[MAGIC3_OFF]);
	}

	offset_imm = magic1 - (magic2^magic3);

	injectNop(decode_at, input->pat_size);
	memcpy(proper_push+1, &offset_imm, sizeof(offset_imm));
	memcpy(decode_at + input->pat_size - sizeof(proper_push), proper_push, sizeof(proper_push));

	printf("PUSH OFFSET 0x%08X\n", offset_imm);
	return S_OK;
}

/*
==========================================================================
                             MOV EBX, offset EF3D80
=========================================================================
.text:00EDC4CF 8D 1D AE 6F EF 00                       lea     ebx, ds:0EF6FAEh	; magic1
.text:00EDC4D5 83 EC 04                                sub     esp, 4
.text:00EDC4D8 89 1C 24                                mov     [esp], ebx
.text:00EDC4DB BB 34 33 00 00                          mov     ebx, 3334h	; magic2
.text:00EDC4E0 81 F3 1A 01 00 00                       xor     ebx, 11Ah	; magic3
.text:00EDC4E6 29 1C 24                                sub     [esp], ebx
.text:00EDC4E9 5B                                      pop     ebx
*/
HRESULT srom_mov_reg_imm32_2(INPUT_HANDLING_FUNCTION* input)
{
	const	int	MAGIC1_OFF	= 0x2;
	const	int MAGIC2_OFF	= 0xD;
	const	int	MAGIC3_OFF	= 0x13;
	const	int	MOV_REG_OFF	= 0x1;

	DWORD	magic1,magic2,magic3,offset_imm, reg_num;
	BYTE	proper_mov[5] = {0xB8,0,0,0,0};

	LPBYTE	decode_at = (LPBYTE) input->pat_match_start;

	/*get magic values*/
	magic1= *((DWORD*)(decode_at+MAGIC1_OFF));
	magic2= *((DWORD*)(decode_at+MAGIC2_OFF));
	magic3= *((DWORD*)(decode_at+MAGIC3_OFF));
	
	reg_num = (decode_at[MOV_REG_OFF] & 0x38)>>3;
	offset_imm = magic1 - (magic2^magic3);

	injectNop(decode_at, input->pat_size);
	memcpy(proper_mov+1, &offset_imm, sizeof(offset_imm));
	proper_mov[0] |= reg_num;
	memcpy(decode_at + input->pat_size - sizeof(proper_mov), proper_mov, sizeof(proper_mov));

	printf("MOV   %s, offset 0x%08X\n", getRegisterString(reg_num), offset_imm);
	return S_OK;
}


const char* getRegisterString(int register_num)
{
	if (register_num>=0 && register_num < 8) {
		return registers_name[register_num];
	}
	return NULL;
}

const char* getJccString(int jccType)
{
	if (jccType>=0 && jccType<=0xF) {
		return jcc_names[jccType];
	}
	return NULL;
}

/*
 Skips all useless opcodes: 
 nop
 xchg regN, regN
 mov  regN, regN
 lea  regN, [regN]
 lea  regN, regN
 lea  regN, [regN+0]
*/
int eat_nop(LPBYTE lp)
{
	DWORD i=0;
	bool round_hit=true;

	while (round_hit)
	{
		round_hit=false;
		// nop
		while (lp[i]==0x90) {
			i++;
			round_hit=true;
		}
		// xchg 
		while (lp[i]==0x87 && (lp[i+1]&0xC0)==0xC0 && (lp[i+1]&0x7)==((lp[i+1]&0x38)>>3)) {
			i+=2;
			round_hit=true;
		}
		// mov
		while (lp[i]==0x8B && (lp[i+1]&0xC0)==0xC0 && (lp[i+1]&0x7)==((lp[i+1]&0x38)>>3)) {
			i+=2;
			round_hit=true;
		}
		// lea type 1
		while (lp[i]==0x8D && (lp[i+1]&0xC0)==0xC0 && (lp[i+1]&0x7)==((lp[i+1]&0x38)>>3)) {
			i+=2;
			round_hit=true;
		}
		// lea type 2
		while (lp[i]==0x8D && (lp[i+1]&0xC0)==0x00 && (lp[i+1]&0x7)==((lp[i+1]&0x38)>>3)) {
			i+=2;
			round_hit=true;
		}
		// lea type 3
		while (lp[i]==0x8D && (lp[i+1]&0xC0)==0x40 && (lp[i+1]&0x7)==((lp[i+1]&0x38)>>3) && lp[i+2]==0) {
			i+=3;
			round_hit=true;
		}

	}

	return i;
}


int reduce_mov_lea_sib_dwordptr_instructions(LPBYTE loc, EVAL_MOV_LEA* eml)
{
	disasm_struct s = {4,4};   // prepare to disasm 32-bit code;

	int imm, scale, index_reg, base_reg, reg, known_val;

	DWORD len = disasm(loc, &s);
	if (len==0) {
		return 0;
	}

	if (s.disasm_opcode != 0x8B && s.disasm_opcode != 0x8D) {
		return 0;
	}

	if ((s.disasm_flag&C_SIB)==C_SIB) {
		scale=(s.disasm_sib>>6);
		index_reg = ((s.disasm_sib&0x38)>>3);
		base_reg = s.disasm_sib&0x7;
	}
	else {
		return 0;
	}

	switch (s.disasm_addrsize) {
	case 0:
		imm=0;
		break;
	case 1:
		imm=sign_extend_8(s.disasm_addr_b[0]);
		break;
	case 4:
		imm=s.disasm_addr_l[0];
		break;
	default:
		return 0;
	}

	if (eml->reg_num==base_reg) {
		reg = index_reg;
		known_val = eml->reg_val + imm;
	}
	else if (eml->reg_num == index_reg) {
		reg = base_reg;
		known_val = (eml->reg_val * (1<<scale)) + imm;
		scale=0;
		return 0; // probably an error
	}
	else {
		return 0;
	}

	// one register is known, so we want to reduce the complex operation to a 5 bytes block
	// of the generic form: "[reg*N + imm32]"
	// 
	eml->block[0] = REG_EBP;
	eml->block[0] |= reg<<3;
	eml->block[0] |= scale<<6;
	*((DWORD*)(eml->block+1)) = known_val;

	eml->imm = known_val;
	eml->index_reg = reg;
	eml->scale = scale;

	return 1;
}