// header for produce_code.cpp
// (c) doug
#ifndef	PRODUCE_CODE_H
#define PRODUCE_CODE_H

DWORD injectNop(void *loc, DWORD numb);
DWORD injectJump(void *loc, DWORD from, DWORD to);
DWORD injectJcc(void *loc, DWORD from, DWORD to, int jccType);
DWORD injectE8Call(void *loc, DWORD from, DWORD to);
DWORD injectCmp(void *loc, int lhs_reg1, bool lhs_has_reg1, int lhs_imm, bool lhs_has_imm, int rhs_reg1, bool rhs_has_reg1, int rhs_imm, bool rhs_has_imm, bool lhs_dwordptr, bool rhs_dwordptr, char *CmpStr, int nCmpStr);
DWORD sign_extend_8(BYTE byte);
#endif // PRODUCE_CODE_H