/*
	produce_code.cpp:

	This is just a quick hack of a code-generator that I put together for this tool.

	(c) doug
*/

#include <windows.h>
#include <stdio.h>
#include "produce_code.h"
#include "srom7_cleaner.h"
#include "handlers.h"


DWORD injectNop(void *loc, DWORD numb)
{
	memset(loc, 0x90, numb);
	return numb;
}


/*
	injects a jmp from "from" to "to"
	jmp is written at "loc"

  the code tries the best possible jump type.
*/
DWORD injectJump(void *loc, DWORD from, DWORD to)
{
	int delta;
	delta=to-from;

	if ((delta&0xFFFFFF00) ==0 && (delta&0x0FF) < 0x80) {
		//short jmp
		delta-=2;
		((BYTE*) loc)[0]=0xEB;
		((BYTE*) loc)[1]=(BYTE) delta;
		return 2;
	}
	else {
		delta-=5;
		((BYTE*) loc)[0]=0xE9;
		((DWORD*) ((BYTE*)loc+1))[0]=delta;
		return 5;
	}
}


DWORD injectJcc(void *loc, DWORD from, DWORD to, int jccType)
{
	int delta;
	delta=to-from;

	if (jccType<0 || jccType>0xF) {
		return 0;
	}

	if ((delta&0xFFFFFF00) ==0 && (delta&0x0FF) < 0x80) {
		//short jmp
		delta-=2;
		((BYTE*) loc)[0]=0x70 | jccType;
		((BYTE*) loc)[1]=(BYTE) delta;
		return 2;
	}
	else {
		delta-=6;
		((BYTE*) loc)[0]=0x0F;
		((BYTE*) loc)[1]=0x80 | jccType;
		((DWORD*) ((BYTE*)loc+2))[0]=delta;
		return 6;
	}

}

/*
		<whatever>
		from:	call	to
		<whatever>
		to:
			...
*/
DWORD injectE8Call(void *loc, DWORD from, DWORD to)
{
	DWORD delta;
	delta=to-(from+5);

	((BYTE*)loc)[0]=0xE8;
	((DWORD*)((BYTE*)loc+1))[0]=delta;
	return 5;
}


	/*
		lhs_has_imm
		lhs_imm
		lhs_reg1
		rhs_has_imm
		rhs_imm
		rhs_reg1

		CMP	 dword ptr [lhs_imm], *
	OR
		CMP  dword ptr [lhs_reg1+lhs_imm], rhs_reg1
	OR
		CMP  dword ptr [lhs_reg1+lhs_imm], rhs_imm
	OR
		CMP	 lhs_reg1, rhs_reg1
	OR
		CMP	 lhs_reg1, rhs_imm
	OR
		CMP  lhs_reg1, dword ptr [rhs_reg1 + rhs_imm]
	*/
DWORD injectCmp(void *loc, int lhs_reg1, bool lhs_has_reg1, int lhs_imm, bool lhs_has_imm, int rhs_reg1, bool rhs_has_reg1, int rhs_imm, bool rhs_has_imm, bool lhs_dwordptr, bool rhs_dwordptr, char *CmpStr, int nCmpStr)
{
	DWORD instr_size;
	char	cmp_full_str[200];
	char	*cmp_str=cmp_full_str;

	memset(cmp_full_str, 0, sizeof(cmp_full_str));
	sprintf(cmp_str,"CMP  ");
	cmp_str= cmp_full_str + strlen(cmp_full_str);

	if (lhs_dwordptr && !lhs_has_reg1 && lhs_has_imm && rhs_has_imm && !rhs_has_reg1) {
		// CMP dword ptr [lhs_imm], rhs_imm
		instr_size=0xA;
		BYTE	instr[] = {0x81, 0x3d,0,0,0,0,0,0,0,0};
		*((DWORD*)((LPBYTE)instr+2)) = lhs_imm;
		*((DWORD*)((LPBYTE)instr+6)) = rhs_imm;
		memcpy(loc, instr, sizeof(instr));

		sprintf(cmp_str,"dword ptr [%08X], %08X", lhs_imm, rhs_imm);
		cmp_str= cmp_str + strlen(cmp_str);
	}
	else if (!lhs_dwordptr && !rhs_dwordptr && rhs_has_imm && !rhs_has_reg1) {
		// CMP lhs_reg1, rhs_imm
		instr_size=6;
		BYTE	instr[] = {0x81,0xF8};

		instr[1] |= lhs_reg1;
		memcpy(loc, instr, sizeof(instr));
		*((DWORD*)((LPBYTE)loc+2)) = rhs_imm;

		sprintf(cmp_str,"%s, %08X", getRegisterString(lhs_reg1), rhs_imm);
		cmp_str= cmp_str + strlen(cmp_str);
	}
	else if (!lhs_dwordptr && !rhs_dwordptr) {
		// CMP lhs_reg1, rhs_reg1
		instr_size=2;
		BYTE	instr[] = {0x3B,0xC0};

		instr[1] |= (lhs_reg1<<3);
		instr[1] |= rhs_reg1;
		memcpy(loc, instr, sizeof(instr));

		sprintf(cmp_str,"%s, %s", getRegisterString(lhs_reg1), getRegisterString(rhs_reg1));
		cmp_str= cmp_str + strlen(cmp_str);
	}
	else if (!lhs_dwordptr && rhs_dwordptr && rhs_has_reg1) {
		// CMP lhs_reg1, dword ptr [rhs_reg1 + rhs_imm]
		// this form is opposite of another one. only the first byte differs.
		// Note: rhs_imm is optional.
		instr_size=6;
		BYTE	instr[] = {0x3B,0x80};

		instr[1] |= lhs_reg1;
		instr[1] |= (rhs_reg1<<3);

		if (!rhs_has_imm) { rhs_imm=0; }

		memcpy(loc, instr, sizeof(instr));
		*((DWORD*)((LPBYTE)loc+2)) = rhs_imm;

		sprintf(cmp_str,"%s, dword ptr [%s + %08X]", getRegisterString(lhs_reg1), getRegisterString(rhs_reg1), rhs_imm);
		cmp_str= cmp_str + strlen(cmp_str);
	}
	else if (lhs_dwordptr && lhs_has_reg1 && !rhs_has_imm) {
		// CMP  dword ptr [lhs_reg1+lhs_imm], rhs_reg1
		// lhs_imm is optional
		instr_size=6;
		BYTE	instr[] = {0x39,0x80};
		
		instr[1] |= lhs_reg1;
		instr[1] |= (rhs_reg1<<3);

		if (!lhs_has_imm) { lhs_imm=0; }

		memcpy(loc, instr, sizeof(instr));
		*((DWORD*)((LPBYTE)loc+2)) = lhs_imm;

		sprintf(cmp_str,"dword ptr [%s + %08X], %s", getRegisterString(lhs_reg1), lhs_imm, getRegisterString(rhs_reg1));
		cmp_str= cmp_str + strlen(cmp_str);
	}
	else if (lhs_dwordptr && lhs_has_reg1 && rhs_has_imm) {
		//CMP  dword ptr [lhs_reg1+lhs_imm], rhs_imm
		instr_size=10;
		BYTE	instr[] = {0x81,0xB8};

		instr[1] |= lhs_reg1;

		if (!lhs_has_imm) { lhs_imm=0; }
		
		memcpy(loc, instr, sizeof(instr));
		*((DWORD*)((LPBYTE)loc+2)) = lhs_imm;
		*((DWORD*)((LPBYTE)loc+6)) = rhs_imm;

		sprintf(cmp_str,"dword ptr [%s + %08X], %08X", getRegisterString(lhs_reg1), lhs_imm, rhs_imm);
		cmp_str= cmp_str + strlen(cmp_str);
	}
	else {
		strcpy(cmp_str, "Unhandled CMP code!!!");
		instr_size=0;
	}

	if (CmpStr!=NULL && nCmpStr!=0) {
		strncpy(CmpStr, cmp_full_str, nCmpStr);
	}

	return instr_size;
}

// sign extends 8-bits to 32
DWORD sign_extend_8(BYTE byte)
{	
	DWORD val=0xFFFFFF00;
	if ((byte&0x80) !=0) {
		val|=byte;
	}
	else {
		val=0;
		val|=byte;
	}

	return val;
}