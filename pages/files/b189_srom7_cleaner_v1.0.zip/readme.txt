                 *    SecuROM v7 Cleaner    *

                             by
                            doug        

v1.0 (Build: ???)


In v5 and v7, SecuROM incorporates a sofisticated code obfuscator engine. It 
is better than any obfuscation I have seen elsewhere, so the simple pattern 
matching of macros do not work very well (at all).

This tool cleans code that was protected/obfuscated with SecuROM's 
code obfuscator. While this tool handles a LOT of things, it is not perfect, 
so don't expect to be able to run files that were cleaned with it. The purpose
of this tool is to simplify a reverse-engineering/security analysis
of those binaries.

Full source code is included (GPL for the files with my name in the header).

This tool only supports PE images. Since starting with some version, 
the securom .text section is compressed, just use LordPE to dump the 
entire process (dump full) to disk at the point where the .init section 
jumps (via a RET) to the real securom entrypoint in .text.


Usage
------
Just run the srom7_cleaner.exe and specify the file that you which to clean.

Recommended: 
  * Redirect the output to a text file. The log can get up to 7 MB large.
    Use the included .bat file for that purpose.

  * First just scan .init to analyze the decompression code. Then dump
    the process when .text (securom's) is unpacked.

  * When the process is dumped, you may clean both .text & .init.

  * Load in IDA and enjoy ;-).


Known issues:
------------
  * The CMP pattern is known to produce a lot of collisions/errors, so I 
    just commented out the line in the source code. The handler needs a 
    little rework before I feel that I can enable it again.


August-2005
doug


Note: this tool uses ADE32 by z0mbie.