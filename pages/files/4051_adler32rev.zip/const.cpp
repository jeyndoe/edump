#include "lpkit.h"
#include <stdio.h>
#include <windows.h>

unsigned int adler32hash(char* data, int len);

int main(int argc, char* argv[])
{

	unsigned int key, len, i, i1, i2, u_i1, u_i2, l_i1, l_i2;
	lprec *lp1;

	printf("input hash:\n");
	scanf("%u",&key);
	printf("input desired length of the string:\n");
	scanf("%u",&len);

	i1 = key & 0xFFFF;
	i2 = key >> 16;

	u_i1 = len*126;
	l_i1 = len*33;
	while(i1<l_i1){
		i1+=65521;
	}

	u_i2 = 126*len*(len+1)/2;
	l_i2 = 33*len*(len+1)/2;
	while(i2<l_i2){
		i2+=65521;
	}

	double *vect;
	vect = (double*)calloc(len+1,sizeof(double));

	lp1=make_lp(0,len);

	vect[1]=1;

	set_obj_fn(lp1, vect);

	
	for(i=1;i<=len;i++){
		vect[i]=1;
	}
	add_constraint(lp1, vect, EQ, i1);

	for(i=1;i<=len;i++){
		vect[i]=len+1-i;
	}
	add_constraint(lp1, vect, EQ, i2);

	for(i=1;i<=len;i++){
		set_int(lp1, i, TRUE);
		set_lowbo(lp1,i,33);
		set_upbo(lp1,i,126);
	}
	
    //print_lp(lp1);	


	int retcode;
	unsigned int i2_old = i2;
	while(i1<u_i1){
		while(i2<u_i2){

			retcode = solve(lp1);
			if(retcode==OPTIMAL){
//				print_solution(lp1);
				char* c = (char*)calloc(len+1,1);

				printf("numerical solution:\n");
				for(i = 1; i <= len; i++) {
					c[i-1] = (char)(lp1->best_solution[lp1->rows+i]);
					printf("[%d] ", c[i-1]);
				}
				printf("\nASCII string solution:\n");
				printf(c);
				printf("\nhash code:\n");
				printf("%u",adler32hash(c,len));
				
				free(c);
				getchar();
				getchar();
				return 0;
			}
			i2+=65521;
			set_rh(lp1,2,i2);
		}
		set_rh(lp1,2,i2_old);
		i1+=65521;
		set_rh(lp1,1,i1);
	}

	printf("no solution for given length");
	
	getchar();
	getchar();

	return 0;
}


unsigned int adler32hash(char* data, int len) {
	unsigned int i1=0,i2=0;
	
	for(int i=0;i<len;i++){
		i1+=data[i];
		i2+=i1;
	}

	i1 %= 65521;
	i2 %= 65521;

	return (i2 << 16) | i1;

}

