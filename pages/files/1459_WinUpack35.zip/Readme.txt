                __   ______   ______   ______   ____
           ____/ /_ _\    /_ _\__  /_ _\    /_ _\  /___
          _\  /   //   /   //       //   /___//   /   /
     ____/   /   //   /   //   /   //   /   //   /   /__
  \\ \__    /   //   /   //   /   //   /   //   /   ___/ //
    ___/   /   //   /   //   /   //   /   //   /   /__
 \\ \_    /   //   /   //   /   //   /   //   /   ___// //
     /_  /   //_  ____//_  /   //_  /   //_     _/
        /______\ /__\     /______\ /______\ /__\___\
     --------------------------------------------------
     (Win)Upack (ultimate PE packer) Version: 0.35alpha

     Author:   Dwing
     Contact:  dwing@163.com
     Homepage: http://dwing.51.net
               http://dwing.wex.cn
               http://www.wex.cn/dwing/

     ====< Introduction >============================================

      Upack is a packer that can compress Windows PE file,
      which can be run without decompressing manually.

      It packs all kinds of PE files with best compression ratio.
      It's only for compression, not for protection mainly.
      Upack can only deal with executable files of PE format.
      DOS-EXEs(MZ), Win3.x-EXE/DLLs(NE) can't be packed by Upack.
      I didn't test many programs and will go on improving it.

      This is an alpha version.
      So if it does't pack one PE file, try UPX or ASPack first.
      If they can pack it normally, send the original PE file to me.
      Remember that it can't pack some weird or self-check PE files.
      So you'd better make backup for your PE file before packing it.

     ====< Files >===================================================

      Upack.exe     --- Console version of Upack
      WinUpackE.exe --- English GUI version of Upack
      WinUpackC.exe --- Chinese GUI version of Upack
      Readme.txt    --- This document file

     ====< Usage (for console version) >=============================

     Syntax:   Upack <PE-filename> [-switches...]
     Switches: -c{0...6}   Set LC param of compression [default:3]
               -f{5...255} Set FB param of compression [default:128]
               -test       Only show the result
               -red        Preserve extra data
               -set        Strip export table
               -srt        Strip relocation table
               -rlc XXXX   Relocate base address to XXXX (HEX)
               -rai        Reserve all icons (don't compress them)
               -force      Force packing suspicious PE file
     Examples: Upack winrar.exe -set
               Upack msvcrt.dll
               Upack notepad.exe -c2 -f32
               Upack winword.exe -c3 -f255 -rlc 400000
               Upack acdsee.exe -c3 -rai
               Upack flash.exe -red -force
               Upack mydll.dll -rlc 60000000

     * The console version only runs under Windows command line
     * DO NOT pack multi-files at the same time
     * Support "Icon Drag&Drop" and "SendTo"
     * Compression result maybe affected by memory size
     * "-rlc" needs base relocation table
     * "-test" does not modify your original file

     ====< History >=================================================

     0.35alpha -12/10/2005
     ---------------------
      *Fix a conflict with ATI OpenGL driver
      *Slim exe depacker about 8 bytes

     0.34alpha - 8/10/2005
     ---------------------
      *Fix a problem that slow down depacking
      *Fix a bug that can't run on WinNT/2000

     0.33alpha - 1/10/2005
     ---------------------
      *Slim exe depacker about 125 bytes!
      -Remove depack code confusion (for EXE)
      *Fix drag&drop bug on Win98 (for GUI) (thank COdEXpLOrER)
      *Some minor changes

     0.32beta  - 13/8/2005
     ---------------------
      +Support packing resource-only DLL
      +Simple random depack code confusion (only for EXE now)
      *Fix minor bugs

     0.31beta  -  4/8/2005
     ---------------------
      *Fix string resource ID bug (thank Luis R0y0)
      *Minor changes

     0.30beta  - 18/7/2005
     ---------------------
      *Fix some bugs about export table
      *Optimize export table size
      *Fix file mapping align bug
      *Fix file open dialog bug (GUI)
      *Minor changes

     0.29beta  -  4/7/2005
     ---------------------
      *Fix MCAFEE virus detecting bug (a little trick)
      *Fix progress control bug (GUI)
      *Fix minor bugs

     0.28alpha -  1/6/2005
     ---------------------
      +Support packing all kinds of PE files (EXE/DLL/OCX/...)
       (oh, so late:]. Depacker size is 589/684 bytes)
      +Support preserving relocation table for EXE file
      +Image base address can be redefined manually (-rlc XXXX)
       (need relocation table)
      *Switches set are changed (-set/-srt)
      *Export and relocation are preserved defaultly for all PE files
      *Fix minor bugs

     0.27beta  -  2/5/2005
     ---------------------
      *Fix minor bugs

     0.26beta  - 26/4/2005
     ---------------------
      *Fix data directories bug

     0.25beta  -  7/4/2005
     ---------------------
      *Use LZMA 4.16 core
      *Fix image head size bug
      *Fix serious memory leak

     0.24beta  - 24/3/2005
     ---------------------
      *Slim depacker 16 bytes (extreme optimization?)

     0.23beta  - 20/3/2005
     ---------------------
      *Fix additional resource bug
      *Slim depacker 1 byte
      +Add an option (-test)

     0.22beta  - 17/3/2005
     ---------------------
      *Slim depacker 13 bytes

     0.21beta  - 10/3/2005
     ---------------------
      *Slim depacker 2 bytes
      *Fix icon resource bug
      +Add an option (-rlc)
      *Reserve REGISTRY resource

     0.20beta  - 05/3/2005
     ---------------------
      *More compatible on Win2000/XP
      *Fix resource compatibility problem
      +Add an option (-red)
      +Add an option (-rai)
      *Reserve version resource
      *Reserve TYPELIB resource
      *Fix multi-language resource bug
      *Fix E8/E9 transformation bug
      *Fix image size bug
      *Use MSC 13.10.3077 as Upack's compiler

     0.12beta  - 27/2/2005
     ----------------------
      +Add an option (-force)
      +Add DLL identification
      *Fix import table bug
      +Add some error message

     0.11beta  - 22/2/2005
     ----------------------
      *Unreserve version resource
      *Fix destination section address bug
      *Fix repack bug
      *Fix stack/heap size bug

     0.10beta  - 25/1/2005
     ----------------------
      *Some details
      +Add some options (-c/-f/-ret)
      *Fix some bugs

     0.09alpha - 11/1/2005
     ----------------------
      *Fix string resource ID bug
      +Add compression progress
      *Fix rebuilding export table bug

     0.08alpha - 10/1/2005
     ----------------------
      *Slim depacker 9 bytes
      *Fix rebuilding import table bug
      +Remove debug data

     0.07alpha - 09/1/2005
     ----------------------
      *Fix compatibility with some OS
      *13 bytes larger than last version

     0.06alpha - 09/1/2005
     ----------------------
      +Add some error information
      +Add displaying in/out file size
      +Auto-size dictionary
      *Slim depacker 1 byte
      *Fix some bugs

     0.05alpha - 08/1/2005
     ----------------------
      *Fix E8/E9 transformation bug
      *Add depacker 3 bytes
      +Strip relocation table
      +Remove copyright data
      *Fix some bugs

     0.04alpha - 07/1/2005
     ----------------------
      +Support export table
      *Fixed revserved icons
      *Slim depacker 2 bytes
      *Fix some bugs

     0.03alpha - 05/01/2005
     ----------------------
      +Support string resource ID
      +Support TLS table
      *Fix some bugs

     0.02alpha - 04/01/2005
     ----------------------
      +E8/E9 address transformation
      +Make PE tighter
      *Fix some bugs

     0.01alpha - 03/01/2005
     ----------------------
      !Initial version
      +LZMA data compression coder
      +Very slim depacker(624 bytes)
      +Very tight PE struct
      +Import table compression
      +Resource compression
      +Support number resource ID
      +Reserve some icons, version, xml resource

     ====< Disclaimer >==============================================

      Dwing(NOT my real name), the author of Upack, disclaims any
      liability for any damage caused by using or misusing this
      software. The author cannot be held responsible for data loss
      or other damages and any consequences from this loss or damages.

     ====< Thanks to >===============================================

     * Igor Pavlov's        LZMA
     * Microsoft's          Visual C++ (also a good assambler)
     * Oleh Yuschuk's       OllyDbg (have hard time with it)
     * Toshifumi Yamamoto's eXeScope
     * Yuri's               Hedit
     * Northfox's           MEW
     * ryg's                kkrunchy
     * URSoftware's         W32Dasm
     * Liu Xingping's       advice & idea
     * rambo/the_loop's     logo
     * Raiko's              icon
     * Lucho, Stanislav, Dmitry and others who care this little tool
 ####################################################################
