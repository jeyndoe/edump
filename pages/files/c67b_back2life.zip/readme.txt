To install Back2Life for TC on computer:
=================================================================

1. Unzip the archive to any directory
2. Launch Total Commander and choose Configuration -> Options -> Operation -> FS-Plugins
3. Click "Add"
4. Go to the directory where the archive was unzipped, and select Back2Life.wfx
5. Click OK.


Contact information
=================================================================
e-mail:   support@GrandUtils.com
web-site: www.GrandUtils.com/Back2Life4TC

Standalone version of Back2Life with some extra features is available at www.GrandUtils.com/Back2Life
