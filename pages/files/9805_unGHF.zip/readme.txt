                        [ GHF UnProtector v0.1]
==========================================================================
=    This tool can unprotect "GHF Protector" protected PE executables    =
==========================================================================
=   Protection Info:                         Unprotection Info:          =
=   ================                         ==================          =
=   Author: GPcH                             Author: arnix               =
=   Web: http://www.dotfix.net               E-mail: arnix@freenet.am    =
=   Release date: 18.04.2005                 Release date: 17.05.2005    =
==========================================================================

note n1: this is my first unpacker, so forgive me if smth is wrong...
note n2: i can share the source code if you ask me about that...

----------
17.05.2005

---
arnix